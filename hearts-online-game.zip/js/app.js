/**
 * Application Entry Point and Bootstrapping
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initialize Web Audio on first user interaction
    const initAudio = () => {
        if (window.soundEngine) {
            window.soundEngine.init();
        }
        document.removeEventListener('click', initAudio);
        document.removeEventListener('keydown', initAudio);
    };
    document.addEventListener('click', initAudio);
    document.addEventListener('keydown', initAudio);

    // Initialize UI and Game
    const ui = new TableUI();
    const initialGame = new HeartsGame({
        humanSeats: [0], // Single player (South = You)
        playerNames: ['You', 'West Bot', 'North Bot', 'East Bot']
    });

    ui.bindGame(initialGame);
    initialGame.startNewGame();

    // Toggle Pass-and-Play human count visibility in New Game modal
    const radioModes = document.querySelectorAll('input[name="game-mode"]');
    const humanCountContainer = document.getElementById('human-count-container');
    radioModes.forEach(r => {
        r.addEventListener('change', (e) => {
            if (humanCountContainer) {
                humanCountContainer.style.display = e.target.value === 'pass-and-play' ? 'block' : 'none';
            }
        });
    });

    console.log('Hearts: Card Game initialized successfully.');
});
