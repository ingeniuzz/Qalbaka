/**
 * Card, Deck, and SVG Card Renderer
 */

const SUITS = {
    CLUBS: 'clubs',
    DIAMONDS: 'diamonds',
    SPADES: 'spades',
    HEARTS: 'hearts'
};

const SUIT_SYMBOLS = {
    clubs: '♣',
    diamonds: '♦',
    spades: '♠',
    hearts: '♥'
};

const SUIT_COLORS = {
    clubs: '#059669',    // High-contrast Emerald Clover Green
    diamonds: '#2563eb', // Royal Sapphire Blue
    spades: '#111827',   // Jet Black
    hearts: '#dc2626'    // Vivid Crimson Red
};

const RANK_NAMES = {
    2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9', 10: '10',
    11: 'J', 12: 'Q', 13: 'K', 14: 'A'
};

class Card {
    constructor(suit, rank) {
        this.suit = suit;
        this.rank = rank; // 2 through 14 (Ace is 14)
        this.name = RANK_NAMES[rank];
        this.symbol = SUIT_SYMBOLS[suit];
        this.color = SUIT_COLORS[suit];
        this.id = `${suit[0]}${rank}`;
        
        // Point values in Hearts
        if (this.suit === SUITS.HEARTS) {
            this.points = 1;
        } else if (this.suit === SUITS.SPADES && this.rank === 12) {
            this.points = 13; // The Black Maria / Queen of Spades
        } else {
            this.points = 0;
        }
    }

    isQueenOfSpades() {
        return this.suit === SUITS.SPADES && this.rank === 12;
    }

    isTwoOfClubs() {
        return this.suit === SUITS.CLUBS && this.rank === 2;
    }

    isHeart() {
        return this.suit === SUITS.HEARTS;
    }

    toString() {
        return `${this.name}${this.symbol}`;
    }
}

class Deck {
    constructor() {
        this.cards = [];
        this.reset();
    }

    reset() {
        this.cards = [];
        for (const suit of Object.values(SUITS)) {
            for (let rank = 2; rank <= 14; rank++) {
                this.cards.push(new Card(suit, rank));
            }
        }
    }

    // Modern Fisher-Yates shuffle
    shuffle() {
        for (let i = this.cards.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.cards[i], this.cards[j]] = [this.cards[j], this.cards[i]];
        }
    }

    dealToPlayers(playerCount = 4) {
        const hands = Array.from({ length: playerCount }, () => []);
        let p = 0;
        while (this.cards.length > 0) {
            hands[p].push(this.cards.pop());
            p = (p + 1) % playerCount;
        }
        return hands;
    }
}

/**
 * Procedural SVG Card Generator
 * Produces crisp, beautiful vector graphics for all 52 card faces with large fonts and distinct 4-color suits.
 */
class CardRenderer {
    static getSuitSvgPath(suit, x, y, scale = 1) {
        const color = SUIT_COLORS[suit] || '#111827';
        const transforms = `transform="translate(${x}, ${y}) scale(${scale})"`;
        switch(suit) {
            case SUITS.HEARTS:
                return `
                    <g ${transforms} fill="${color}">
                        <path d="M12,21.35 C11.5,21.35 3.8,14.6 2,9.2 C0.5,5.2 3.6,1.4 8,1.9 C10.2,2.1 11.4,3.5 12,4.6 C12.6,3.5 13.8,2.1 16,1.9 C20.4,1.4 23.5,5.2 22,9.2 C20.2,14.6 12.5,21.35 12,21.35 Z" />
                    </g>
                `;
            case SUITS.DIAMONDS:
                return `
                    <g ${transforms} fill="${color}">
                        <polygon points="12,0.8 22.5,12 12,23.2 1.5,12" />
                    </g>
                `;
            case SUITS.SPADES:
                return `
                    <g ${transforms} fill="${color}">
                        <path d="M12,1.2 C12,1.2 2.5,10.5 2.5,15.2 C2.5,18.5 5.2,20.2 8.5,20.1 C10,20 11.2,19.2 12,18.2 C12.8,19.2 14,20 15.5,20.1 C18.8,20.2 21.5,18.5 21.5,15.2 C21.5,10.5 12,1.2 12,1.2 Z" />
                        <path d="M10.2,17.5 L13.8,17.5 L15.5,23.2 L8.5,23.2 Z" />
                    </g>
                `;
            case SUITS.CLUBS:
                // Authentic, crisp 3-leaf clover
                return `
                    <g ${transforms} fill="${color}">
                        <circle cx="12" cy="6.8" r="5" />
                        <circle cx="6.8" cy="14" r="5" />
                        <circle cx="17.2" cy="14" r="5" />
                        <circle cx="12" cy="12" r="3.2" />
                        <path d="M10.5,13 L13.5,13 L15.5,23.2 L8.5,23.2 Z" />
                    </g>
                `;
            default:
                return '';
        }
    }

    static renderCardFace(card, options = {}) {
        const color = card.color;
        const isQueenOfSpades = card.isQueenOfSpades();

        // Special gold halo border for Queen of Spades (MobilityWare style)
        const borderStroke = isQueenOfSpades ? '#d97706' : '#cbd5e1';
        const borderWidth = isQueenOfSpades ? '2.5' : '1.2';

        // Face card decorative center
        let centerContent = '';
        if (card.rank >= 11 && card.rank <= 13) {
            let royalTitle = card.rank === 11 ? 'JACK' : (card.rank === 12 ? 'QUEEN' : 'KING');
            if (isQueenOfSpades) royalTitle = '★ QUEEN ★';
            
            const badgeBg = card.suit === SUITS.HEARTS ? '#fee2e2' : (card.suit === SUITS.DIAMONDS ? '#dbeafe' : (card.suit === SUITS.CLUBS ? '#d1fae5' : '#f1f5f9'));

            centerContent = `
                <g transform="translate(18, 27)">
                    <rect width="54" height="74" rx="8" fill="${isQueenOfSpades ? '#fffbeb' : '#f8fafc'}" stroke="${isQueenOfSpades ? '#d97706' : '#cbd5e1'}" stroke-width="1.8" />
                    <circle cx="27" cy="30" r="19" fill="${badgeBg}" />
                    <text x="27" y="38" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="25" text-anchor="middle" fill="${color}">${card.name}</text>
                    <text x="27" y="58" font-family="system-ui, sans-serif" font-weight="800" font-size="7.5" letter-spacing="1" text-anchor="middle" fill="${isQueenOfSpades ? '#b45309' : '#475569'}">${royalTitle}</text>
                    <g transform="translate(15, 65) scale(1.0)">${this.getSuitSvgPath(card.suit, 0, 0, 1)}</g>
                </g>
            `;
        } else if (card.rank === 14) {
            // Ace Center - Large bold emblem
            centerContent = `
                <g transform="translate(24, 42) scale(1.75)">
                    ${this.getSuitSvgPath(card.suit, 0, 0, 1)}
                </g>
            `;
        } else {
            // Number cards: central arrangement of suit symbols
            centerContent = this.renderPipLayout(card);
        }

        return `
            <svg class="playing-card-svg" viewBox="0 0 90 128" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <linearGradient id="card-grad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stop-color="#ffffff" />
                        <stop offset="100%" stop-color="${isQueenOfSpades ? '#fffcf0' : '#f8fafc'}" />
                    </linearGradient>
                </defs>
                <!-- Card background -->
                <rect x="1" y="1" width="88" height="126" rx="8" fill="url(#card-grad)" stroke="${borderStroke}" stroke-width="${borderWidth}" />
                
                ${isQueenOfSpades ? `
                <!-- Queen of Spades danger banner -->
                <rect x="2" y="2" width="86" height="15" rx="6" fill="#fef3c7" />
                <text x="45" y="11" font-family="system-ui, sans-serif" font-weight="900" font-size="8" fill="#b45309" text-anchor="middle" letter-spacing="0.5">13 PTS (DANGER)</text>
                ` : ''}

                <!-- Top Left Index: Big Bold Font & Clear Icon -->
                <g transform="translate(6, ${isQueenOfSpades ? 22 : 9})">
                    <text x="5" y="16" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="19" fill="${color}" text-anchor="middle">${card.name}</text>
                    <g transform="translate(-7, 20) scale(1.0)">${this.getSuitSvgPath(card.suit, 0, 0, 1)}</g>
                </g>

                <!-- Bottom Right Index (Rotated 180): Big Bold Font & Clear Icon -->
                <g transform="translate(84, 119) rotate(180)">
                    <text x="5" y="16" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="19" fill="${color}" text-anchor="middle">${card.name}</text>
                    <g transform="translate(-7, 20) scale(1.0)">${this.getSuitSvgPath(card.suit, 0, 0, 1)}</g>
                </g>

                <!-- Center Card Face -->
                ${centerContent}
            </svg>
        `;
    }

    static renderPipLayout(card) {
        const count = card.rank;
        let pips = '';
        const scale = count > 8 ? 0.72 : 0.8;

        // Coordinates tailored for 24x24 suit glyphs scaled by 0.72-0.8
        const layouts = {
            2: [[33, 24], [33, 80]],
            3: [[33, 24], [33, 52], [33, 80]],
            4: [[22, 24], [44, 24], [22, 80], [44, 80]],
            5: [[22, 24], [44, 24], [33, 52], [22, 80], [44, 80]],
            6: [[22, 24], [44, 24], [22, 52], [44, 52], [22, 80], [44, 80]],
            7: [[22, 24], [44, 24], [33, 38], [22, 52], [44, 52], [22, 80], [44, 80]],
            8: [[22, 24], [44, 24], [33, 36], [22, 52], [44, 52], [33, 68], [22, 80], [44, 80]],
            9: [[22, 22], [44, 22], [22, 42], [44, 42], [33, 52], [22, 62], [44, 62], [22, 82], [44, 82]],
            10: [[22, 20], [44, 20], [33, 32], [22, 44], [44, 44], [22, 60], [44, 60], [33, 72], [22, 84], [44, 84]]
        };

        const coords = layouts[count] || [[33, 52]];
        coords.forEach(([x, y]) => {
            pips += `<g transform="translate(${x}, ${y}) scale(${scale})">${this.getSuitSvgPath(card.suit, 0, 0, 1)}</g>`;
        });
        return pips;
    }

    static renderCardBack(theme = 'blue') {
        const patterns = {
            blue: { primary: '#1e3a8a', secondary: '#2563eb', border: '#172554', accent: '#93c5fd' },
            red: { primary: '#991b1b', secondary: '#dc2626', border: '#7f1d1d', accent: '#fca5a5' },
            gold: { primary: '#78350f', secondary: '#d97706', border: '#451a03', accent: '#fef08a' },
            dark: { primary: '#0f172a', secondary: '#334155', border: '#020617', accent: '#94a3b8' }
        };
        const p = patterns[theme] || patterns.blue;

        return `
            <svg class="playing-card-svg card-back-svg" viewBox="0 0 90 128" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <pattern id="card-lattice-${theme}" width="12" height="12" patternUnits="userSpaceOnUse">
                        <path d="M 0 6 L 6 0 L 12 6 L 6 12 Z" fill="none" stroke="${p.secondary}" stroke-width="1.2" />
                        <circle cx="6" cy="6" r="1.5" fill="${p.accent}" />
                    </pattern>
                </defs>
                <rect x="1" y="1" width="88" height="126" rx="8" fill="#ffffff" stroke="#94a3b8" stroke-width="1" />
                <rect x="5" y="5" width="80" height="118" rx="6" fill="${p.primary}" stroke="${p.border}" stroke-width="1.5" />
                <rect x="8" y="8" width="74" height="112" rx="4" fill="url(#card-lattice-${theme})" />
                <rect x="22" y="38" width="46" height="52" rx="23" fill="${p.primary}" stroke="${p.accent}" stroke-width="1.5" />
                <g transform="translate(37, 56) scale(1)">
                    <path fill="${p.accent}" d="M0,4 A4,4 0 0,1 8,4 A4,4 0 0,1 16,4 Q16,9 8,15 Q0,9 0,4 Z" />
                </g>
            </svg>
        `;
    }
}

window.SUITS = SUITS;
window.Card = Card;
window.Deck = Deck;
window.CardRenderer = CardRenderer;
