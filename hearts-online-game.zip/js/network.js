/**
 * Hearts Online Multiplayer Cloud Engine
 * Powers real-time .io-style online multiplayer across any network, mobile or PC.
 * Uses secure WebSockets (WSS) over public cloud brokers (HiveMQ & EMQX)
 * with zero NAT router restrictions, zero API keys, and instant connectivity.
 */

class HeartsNetwork {
    constructor() {
        this.client = null;
        this.isHost = false;
        this.isConnected = false;
        this.isInGame = false;

        this.roomCode = null;
        this.roomPassword = null;
        this.myPlayerName = 'Player 1';
        this.myAvatar = '🧑‍💼';
        this.mySeatIndex = 0; // 0: South (Host), 1: West (Friend), 2: North, 3: East
        this.clientId = 'hearts_' + Math.random().toString(36).substring(2, 10);
        this.roomTopic = null;

        // Public WebSocket MQTT Brokers with auto-failover
        this.brokers = [
            'wss://broker.hivemq.com:8884/mqtt',
            'wss://broker.emqx.io:8084/mqtt'
        ];
        this.currentBrokerIndex = 0;

        this.lobbySeats = [
            { seatIndex: 0, name: 'Host', isHuman: true, isConnected: true, isBot: false, avatar: '🧑‍💼' },
            { seatIndex: 1, name: 'Waiting for friend...', isHuman: true, isConnected: false, isBot: false, avatar: '🧑‍💻' },
            { seatIndex: 2, name: 'Bot Oliver', isHuman: false, isConnected: true, isBot: true, avatar: '🦊' },
            { seatIndex: 3, name: 'Bot Luna', isHuman: false, isConnected: true, isBot: true, avatar: '🦉' }
        ];

        this.connectedGuests = {}; // { guestClientId: { seatIndex, name, avatar } }
        this.gameMode = 'classic';

        // UI Callbacks
        this.onLobbyUpdated = null;
        this.onConnectionStatus = null;
        this.onError = null;
        this.onChatMessage = null;
        this.onEmoteReceived = null;

        // In-Game Sync Callbacks
        this.onGameStarted = null;
        this.onRoundDealt = null;
        this.onPassStagePrompt = null;
        this.onPassExchanged = null;
        this.onTurnUpdated = null;
        this.onCardPlayed = null;
        this.onTrickCompleted = null;
        this.onTrickSwept = null;
        this.onRoundCompleted = null;
        this.onGameOver = null;
    }

    /**
     * Cleans room code
     */
    static formatRoomCode(code) {
        return (code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    }

    /**
     * Generates a readable 6-character room code like HEARTS-4K9P
     */
    static generateRoomCode() {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        let code = 'HEARTS-';
        for (let i = 0; i < 4; i++) {
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
    }

    /**
     * Gets shareable direct-invite link with room code and password
     */
    getShareableLink() {
        if (!this.roomCode) return '';
        const origin = window.location.origin;
        const pathname = window.location.pathname;
        const roomParam = encodeURIComponent(this.roomCode);
        const pwdParam = encodeURIComponent(this.roomPassword || '');
        return `${origin}${pathname}?room=${roomParam}&pwd=${pwdParam}`;
    }

    /**
     * Connects to public WebSocket cloud broker
     */
    connectToCloudBroker(onConnectSuccess) {
        if (typeof mqtt === 'undefined') {
            if (this.onError) this.onError('Multiplayer networking library is loading. Please check internet connection.');
            return;
        }

        if (this.client && this.client.connected) {
            if (onConnectSuccess) onConnectSuccess();
            return;
        }

        const brokerUrl = this.brokers[this.currentBrokerIndex];
        if (this.onConnectionStatus) this.onConnectionStatus(`Connecting to live cloud room server...`);

        try {
            this.client = mqtt.connect(brokerUrl, {
                clientId: this.clientId,
                clean: true,
                connectTimeout: 7000,
                reconnectPeriod: 2500
            });
        } catch (e) {
            console.error('MQTT connect exception:', e);
            this.tryNextBroker(onConnectSuccess);
            return;
        }

        this.client.on('connect', () => {
            console.log(`Connected to cloud relay: ${brokerUrl}`);
            if (this.roomTopic) {
                this.client.subscribe(this.roomTopic, { qos: 1 });
            }
            if (onConnectSuccess) onConnectSuccess();
        });

        this.client.on('message', (topic, message) => {
            try {
                const data = JSON.parse(message.toString());
                this.handleIncomingMessage(data);
            } catch (e) {
                console.error('Message parse error:', e);
            }
        });

        this.client.on('error', (err) => {
            console.warn('Cloud broker connection warning:', err);
            this.tryNextBroker(onConnectSuccess);
        });

        this.client.on('offline', () => {
            console.log('Cloud broker offline, waiting or switching...');
        });
    }

    tryNextBroker(onConnectSuccess) {
        if (this.client) {
            try { this.client.end(true); } catch (e) {}
            this.client = null;
        }
        this.currentBrokerIndex = (this.currentBrokerIndex + 1) % this.brokers.length;
        setTimeout(() => {
            if (this.roomTopic) {
                this.connectToCloudBroker(onConnectSuccess);
            }
        }, 1200);
    }

    /**
     * Publishes a message to the room topic
     */
    publish(payload) {
        if (!this.client || !this.client.connected || !this.roomTopic) {
            return;
        }
        const fullPayload = {
            ...payload,
            roomCode: this.roomCode,
            senderId: this.clientId,
            timestamp: Date.now()
        };
        try {
            this.client.publish(this.roomTopic, JSON.stringify(fullPayload), { qos: 1 });
        } catch (e) {
            console.error('Publish error:', e);
        }
    }

    // =========================================================================
    // HOST: CREATE ROOM
    // =========================================================================

    createRoom({ roomCode, password, hostName, avatar, gameMode = 'classic' }) {
        this.leaveRoom();

        this.isHost = true;
        this.roomCode = (roomCode || HeartsNetwork.generateRoomCode()).toUpperCase().trim();
        this.roomPassword = (password || '').trim();
        this.myPlayerName = hostName || 'Host';
        this.myAvatar = avatar || '🧑‍💼';
        this.mySeatIndex = 0;
        this.gameMode = gameMode;
        this.connectedGuests = {};

        this.roomTopic = `agy-hearts-v2/room/${HeartsNetwork.formatRoomCode(this.roomCode)}`;

        this.lobbySeats = [
            { seatIndex: 0, name: this.myPlayerName, isHuman: true, isConnected: true, isBot: false, avatar: this.myAvatar },
            { seatIndex: 1, name: 'Waiting for friend...', isHuman: true, isConnected: false, isBot: false, avatar: '🧑‍💻' },
            { seatIndex: 2, name: 'Bot Oliver', isHuman: false, isConnected: true, isBot: true, avatar: '🦊' },
            { seatIndex: 3, name: 'Bot Luna', isHuman: false, isConnected: true, isBot: true, avatar: '🦉' }
        ];

        this.connectToCloudBroker(() => {
            this.isConnected = true;
            if (this.onConnectionStatus) this.onConnectionStatus(`Room live! Code: ${this.roomCode}`);
            if (this.onLobbyUpdated) this.onLobbyUpdated(this.lobbySeats, this.roomCode, this.roomPassword);

            // Announce room created on topic
            this.publish({
                type: 'room_ready',
                hostName: this.myPlayerName,
                hasPassword: !!this.roomPassword
            });
        });
    }

    // =========================================================================
    // GUEST: JOIN ROOM
    // =========================================================================

    joinRoom({ roomCode, password, playerName, avatar }) {
        this.leaveRoom();

        this.isHost = false;
        this.roomCode = (roomCode || '').toUpperCase().trim();
        this.roomPassword = (password || '').trim();
        this.myPlayerName = playerName || 'Guest';
        this.myAvatar = avatar || '🧑‍💻';

        if (!this.roomCode) {
            if (this.onError) this.onError('Please enter a valid room code.');
            return;
        }

        this.roomTopic = `agy-hearts-v2/room/${HeartsNetwork.formatRoomCode(this.roomCode)}`;

        if (this.onConnectionStatus) this.onConnectionStatus(`Connecting to room ${this.roomCode}...`);

        this.connectToCloudBroker(() => {
            if (this.onConnectionStatus) this.onConnectionStatus(`Connected to cloud server! Requesting to join room ${this.roomCode}...`);
            // Send join request to host
            this.publish({
                type: 'join_request',
                roomCode: this.roomCode,
                password: this.roomPassword,
                playerName: this.myPlayerName,
                avatar: this.myAvatar
            });

            // Set timeout in case room doesn't exist
            this._joinTimeout = setTimeout(() => {
                if (!this.isConnected) {
                    if (this.onError) this.onError(`Room "${this.roomCode}" was not found or the host has not opened it yet. Please double check the code.`);
                }
            }, 8000);
        });
    }

    // =========================================================================
    // CENTRAL MESSAGE DISPATCHER
    // =========================================================================

    handleIncomingMessage(data) {
        if (!data || !data.type) return;

        // Ignore messages sent by ourselves
        if (data.senderId === this.clientId) return;

        // -----------------------------------------------------
        // HOST SPECIFIC MESSAGE HANDLING
        // -----------------------------------------------------
        if (this.isHost) {
            if (data.type === 'join_request') {
                this.handleHostJoinRequest(data);
                return;
            } else if (data.type === 'pass_cards') {
                if (window.tableUI && window.tableUI.game) {
                    const cards = (data.cards || []).map(c => new Card(c.suit, c.rank));
                    window.tableUI.game.setPlayerPassSelection(data.senderSeat, cards);
                }
                return;
            } else if (data.type === 'play_card') {
                if (window.tableUI && window.tableUI.game) {
                    const card = new Card(data.card.suit, data.card.rank);
                    window.tableUI.game.playCard(data.senderSeat, card);
                }
                return;
            } else if (data.type === 'chat') {
                if (this.onChatMessage) this.onChatMessage(data.senderSeat, data.senderName, data.text);
                return;
            } else if (data.type === 'emote') {
                if (this.onEmoteReceived) this.onEmoteReceived(data.senderSeat, data.emote);
                return;
            } else if (data.type === 'guest_leave') {
                this.handleHostGuestLeave(data);
                return;
            }
        }

        // -----------------------------------------------------
        // GUEST SPECIFIC MESSAGE HANDLING
        // -----------------------------------------------------
        if (!this.isHost) {
            if (data.type === 'join_accepted' && data.targetId === this.clientId) {
                clearTimeout(this._joinTimeout);
                this.isConnected = true;
                this.mySeatIndex = data.seatIndex;
                this.gameMode = data.gameMode;
                this.lobbySeats = data.lobbySeats || [];

                if (this.onConnectionStatus) this.onConnectionStatus(`Connected to room ${this.roomCode}! You are in Seat ${this.mySeatIndex + 1}.`);
                if (this.onLobbyUpdated) this.onLobbyUpdated(this.lobbySeats, this.roomCode, this.roomPassword);
                if (window.soundEngine) window.soundEngine.playCardSnap();
                return;
            } else if (data.type === 'join_rejected' && data.targetId === this.clientId) {
                clearTimeout(this._joinTimeout);
                if (this.onError) this.onError(data.reason || 'Failed to join room.');
                this.leaveRoom();
                return;
            } else if (data.type === 'lobby_update') {
                this.lobbySeats = data.lobbySeats || [];
                if (this.onLobbyUpdated) this.onLobbyUpdated(this.lobbySeats, this.roomCode, this.roomPassword);
                return;
            } else if (data.type === 'game_start') {
                this.isInGame = true;
                if (this.onGameStarted) this.onGameStarted(data);
                return;
            } else if (data.type === 'round_dealt') {
                if (data.targetSeat === this.mySeatIndex) {
                    if (this.onRoundDealt) this.onRoundDealt(data);
                }
                return;
            } else if (data.type === 'pass_stage_prompt') {
                if (this.onPassStagePrompt) this.onPassStagePrompt(data);
                return;
            } else if (data.type === 'pass_exchanged') {
                if (data.targetSeat === this.mySeatIndex) {
                    if (this.onPassExchanged) this.onPassExchanged(data);
                }
                return;
            } else if (data.type === 'turn_update') {
                if (this.onTurnUpdated) this.onTurnUpdated(data);
                return;
            } else if (data.type === 'card_played') {
                if (this.onCardPlayed) this.onCardPlayed(data);
                return;
            } else if (data.type === 'trick_complete') {
                if (this.onTrickCompleted) this.onTrickCompleted(data);
                return;
            } else if (data.type === 'trick_sweep') {
                if (this.onTrickSwept) this.onTrickSwept(data);
                return;
            } else if (data.type === 'round_complete') {
                if (this.onRoundCompleted) this.onRoundCompleted(data);
                return;
            } else if (data.type === 'game_over') {
                if (this.onGameOver) this.onGameOver(data);
                return;
            } else if (data.type === 'chat') {
                if (this.onChatMessage) this.onChatMessage(data.senderSeat, data.senderName, data.text);
                return;
            } else if (data.type === 'emote') {
                if (this.onEmoteReceived) this.onEmoteReceived(data.senderSeat, data.emote);
                return;
            } else if (data.type === 'player_disconnected') {
                if (this.onConnectionStatus) this.onConnectionStatus(data.message);
                return;
            }
        }
    }

    /**
     * Host validates password and seats incoming guest
     */
    handleHostJoinRequest(data) {
        const incomingPwd = (data.password || '').trim();

        // 1. Check password
        if (incomingPwd !== this.roomPassword) {
            this.publish({
                type: 'join_rejected',
                targetId: data.senderId,
                reason: 'Incorrect room password. Please verify the password and try again.'
            });
            return;
        }

        // 2. Find open seat
        let assignedSeat = -1;
        for (let i = 1; i < 4; i++) {
            if (this.lobbySeats[i].isHuman && !this.lobbySeats[i].isConnected) {
                assignedSeat = i;
                break;
            }
        }

        if (assignedSeat === -1 && !this.isInGame) {
            for (let i = 1; i < 4; i++) {
                if (this.lobbySeats[i].isBot) {
                    assignedSeat = i;
                    break;
                }
            }
        }

        if (assignedSeat === -1) {
            this.publish({
                type: 'join_rejected',
                targetId: data.senderId,
                reason: 'This room is currently full.'
            });
            return;
        }

        const guestName = data.playerName || `Player ${assignedSeat + 1}`;
        const guestAvatar = data.avatar || '🧑‍💻';

        this.lobbySeats[assignedSeat] = {
            seatIndex: assignedSeat,
            name: guestName,
            avatar: guestAvatar,
            isHuman: true,
            isConnected: true,
            isBot: false,
            clientId: data.senderId
        };

        this.connectedGuests[data.senderId] = {
            seatIndex: assignedSeat,
            name: guestName,
            avatar: guestAvatar
        };

        // Send acceptance to guest
        this.publish({
            type: 'join_accepted',
            targetId: data.senderId,
            seatIndex: assignedSeat,
            roomCode: this.roomCode,
            hostName: this.myPlayerName,
            gameMode: this.gameMode,
            lobbySeats: this.lobbySeats
        });

        // Broadcast updated lobby
        this.publish({
            type: 'lobby_update',
            lobbySeats: this.lobbySeats
        });

        if (this.onLobbyUpdated) this.onLobbyUpdated(this.lobbySeats, this.roomCode, this.roomPassword);
        if (this.onConnectionStatus) this.onConnectionStatus(`${guestName} joined the room!`);
        if (window.soundEngine) window.soundEngine.playCardSnap();
    }

    handleHostGuestLeave(data) {
        const guestInfo = this.connectedGuests[data.senderId];
        if (!guestInfo) return;

        const seat = guestInfo.seatIndex;
        delete this.connectedGuests[data.senderId];

        if (this.isInGame) {
            this.lobbySeats[seat].name = `Bot ${guestInfo.name}`;
            this.lobbySeats[seat].isBot = true;
            this.lobbySeats[seat].isHuman = false;
            this.lobbySeats[seat].isConnected = false;

            if (window.tableUI && window.tableUI.game) {
                const p = window.tableUI.game.players[seat];
                if (p) {
                    p.isHuman = false;
                    p.name = `Bot ${guestInfo.name}`;
                }
                window.tableUI.game.humanSeats = window.tableUI.game.humanSeats.filter(s => s !== seat);
            }

            this.publish({
                type: 'player_disconnected',
                seatIndex: seat,
                message: `${guestInfo.name} disconnected. Replaced by an AI bot.`
            });
        } else {
            this.lobbySeats[seat].name = 'Waiting for friend...';
            this.lobbySeats[seat].isConnected = false;
            this.lobbySeats[seat].isBot = false;
            this.lobbySeats[seat].isHuman = true;

            this.publish({
                type: 'lobby_update',
                lobbySeats: this.lobbySeats
            });
        }

        if (this.onLobbyUpdated) this.onLobbyUpdated(this.lobbySeats, this.roomCode, this.roomPassword);
        if (this.onConnectionStatus) this.onConnectionStatus(`${guestInfo.name} left the room.`);
    }

    // =========================================================================
    // BROADCASTING API
    // =========================================================================

    broadcastToGuests(data) {
        if (!this.isHost) return;
        this.publish(data);
    }

    sendToGuest(seatIndex, data) {
        if (!this.isHost) return;
        this.publish({
            ...data,
            targetSeat: seatIndex
        });
    }

    sendToHost(data) {
        this.publish(data);
    }

    submitPassCards(cards) {
        this.publish({
            type: 'pass_cards',
            senderSeat: this.mySeatIndex,
            cards: cards.map(c => ({ suit: c.suit, rank: c.rank, id: c.id }))
        });
    }

    playCard(card) {
        this.publish({
            type: 'play_card',
            senderSeat: this.mySeatIndex,
            card: { suit: card.suit, rank: card.rank, id: card.id }
        });
    }

    sendEmote(emote) {
        this.publish({
            type: 'emote',
            senderSeat: this.mySeatIndex,
            emote
        });
        if (this.onEmoteReceived) this.onEmoteReceived(this.mySeatIndex, emote);
    }

    sendChatMessage(text) {
        const clean = (text || '').trim();
        if (!clean) return;
        this.publish({
            type: 'chat',
            senderSeat: this.mySeatIndex,
            senderName: this.myPlayerName,
            text: clean
        });
        if (this.onChatMessage) this.onChatMessage(this.mySeatIndex, this.myPlayerName, clean);
    }

    leaveRoom() {
        if (this.client && this.client.connected && this.roomTopic) {
            if (!this.isHost) {
                this.publish({ type: 'guest_leave' });
            }
            try { this.client.unsubscribe(this.roomTopic); } catch (e) {}
        }
        if (this.client) {
            try { this.client.end(true); } catch (e) {}
            this.client = null;
        }

        this.isInGame = false;
        this.isConnected = false;
        this.roomCode = null;
        this.roomPassword = null;
        this.roomTopic = null;
        this.isHost = false;
        this.connectedGuests = {};
    }
}

window.HeartsNetwork = HeartsNetwork;
window.heartsNetwork = new HeartsNetwork();
