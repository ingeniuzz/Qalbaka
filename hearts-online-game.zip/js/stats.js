/**
 * Statistics and Settings Manager (LocalStorage)
 */

class StatsManager {
    static SETTINGS_KEY = 'hearts_game_settings';
    static STATS_KEY = 'hearts_game_stats';

    static defaultSettings = {
        soundEnabled: true,
        animationSpeed: 'normal', // 'slow' | 'normal' | 'fast'
        tableTheme: 'green', // 'green' | 'navy' | 'crimson' | 'wood'
        cardBackTheme: 'blue', // 'blue' | 'red' | 'gold' | 'dark'
        targetScore: 100, // 50 | 75 | 100
        moonRule: 'punishOpponents', // 'punishOpponents' | 'bonusShooter'
        aiDifficulty: 'hard', // 'easy' | 'medium' | 'hard'
        passAndPlayPrivacy: true // Privacy curtain between human turns
    };

    static defaultStats = {
        gamesPlayed: 0,
        gamesWon: 0,
        handsPlayed: 0,
        moonShots: 0,
        bestScore: null,
        totalPoints: 0,
        recentMatches: []
    };

    static loadSettings() {
        try {
            const raw = localStorage.getItem(this.SETTINGS_KEY);
            return raw ? { ...this.defaultSettings, ...JSON.parse(raw) } : { ...this.defaultSettings };
        } catch (e) {
            return { ...this.defaultSettings };
        }
    }

    static saveSettings(settings) {
        try {
            localStorage.setItem(this.SETTINGS_KEY, JSON.stringify(settings));
        } catch (e) {
            console.error('Failed to save settings to localStorage:', e);
        }
    }

    static loadStats() {
        try {
            const raw = localStorage.getItem(this.STATS_KEY);
            return raw ? { ...this.defaultStats, ...JSON.parse(raw) } : { ...this.defaultStats };
        } catch (e) {
            return { ...this.defaultStats };
        }
    }

    static saveStats(stats) {
        try {
            localStorage.setItem(this.STATS_KEY, JSON.stringify(stats));
        } catch (e) {
            console.error('Failed to save stats to localStorage:', e);
        }
    }

    static recordGameCompletion(winnerIndex, humanPlayers, allScores, shotMoon = false) {
        const stats = this.loadStats();
        stats.gamesPlayed += 1;

        const isHumanWinner = humanPlayers.includes(winnerIndex);
        if (isHumanWinner) {
            stats.gamesWon += 1;
        }

        if (shotMoon) {
            stats.moonShots += 1;
        }

        const humanScore = allScores[humanPlayers[0] || 0];
        stats.totalPoints += humanScore;

        if (stats.bestScore === null || humanScore < stats.bestScore) {
            stats.bestScore = humanScore;
        }

        const matchRecord = {
            date: new Date().toLocaleDateString(),
            winner: winnerIndex === 0 ? 'You' : `Player ${winnerIndex + 1}`,
            scores: [...allScores],
            isWin: isHumanWinner
        };

        stats.recentMatches.unshift(matchRecord);
        if (stats.recentMatches.length > 10) {
            stats.recentMatches.pop();
        }

        this.saveStats(stats);
        return stats;
    }

    static resetStats() {
        this.saveStats({ ...this.defaultStats });
    }
}

window.StatsManager = StatsManager;
