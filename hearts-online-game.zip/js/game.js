/**
 * Game Controller and State Machine for Hearts
 */

class HeartsGame {
    static PHASES = {
        IDLE: 'idle',
        DEALING: 'dealing',
        PASSING: 'passing',
        PLAYING: 'playing',
        ROUND_END: 'round_end',
        GAME_OVER: 'game_over'
    };

    constructor(options = {}) {
        this.settings = StatsManager.loadSettings();
        this.gameMode = options.gameMode || HeartsRules.GAME_MODES.CLASSIC;
        this.playerCount = 4;
        this.humanSeats = options.humanSeats || [0]; // default: Player 0 (South) is Human
        this.playerNames = options.playerNames || ['You', 'West Bot', 'North Bot', 'East Bot'];
        
        this.players = [];
        this.roundNumber = 1;
        this.currentPhase = HeartsGame.PHASES.IDLE;
        this.passDirection = HeartsRules.PASS_DIRECTIONS.LEFT;
        this.passStage = 1; // Used in Triple Pass mode (1: Left, 2: Across/Front, 3: Right)
        
        // Trick state
        this.trickNumber = 1;
        this.currentTrick = []; // Array<{playerIndex: number, card: Card}>
        this.activePlayerIndex = 0;
        this.heartsBroken = false;
        this.playedCards = []; // History of all cards played in current round
        
        // Undo history stack for single player
        this.trickHistory = [];

        // Callbacks for UI updates
        this.onStateChange = null;
        this.onCardPlayed = null;
        this.onTrickComplete = null;
        this.onTrickSweep = null;
        this.onRoundComplete = null;
        this.onGameOver = null;
        this.onPassStepPrompt = null; // Used for Pass-and-Play privacy curtains

        this.initPlayers();
    }

    initPlayers() {
        this.players = [];
        const avatars = ['🧑‍💼', '🤖', '🦊', '🦉'];
        for (let i = 0; i < 4; i++) {
            const isHuman = this.humanSeats.includes(i);
            this.players.push({
                index: i,
                name: this.playerNames[i] || (isHuman ? `Player ${i + 1}` : `Bot ${i + 1}`),
                isHuman: isHuman,
                avatar: avatars[i],
                hand: [],
                passedCards: [],
                receivedCards: [],
                tricksTaken: [],
                roundPoints: 0,
                totalScore: 0,
                scoreHistory: [],
                memory: {
                    passedCards: [],
                    passedTo: null,
                    attemptingMoon: false
                }
            });
        }
    }

    startNewGame() {
        this.roundNumber = 1;
        this.players.forEach(p => {
            p.totalScore = 0;
            p.scoreHistory = [];
        });
        this.startNewRound();
    }

    startNewRound() {
        this.currentPhase = HeartsGame.PHASES.DEALING;
        if (this.gameMode === HeartsRules.GAME_MODES.TRIPLE_PASS) {
            this.passStage = 1;
            this.passDirection = HeartsRules.getTriplePassDirection(this.passStage);
        } else {
            this.passDirection = HeartsRules.getPassDirection(this.roundNumber);
        }
        this.trickNumber = 1;
        this.currentTrick = [];
        this.heartsBroken = false;
        this.playedCards = [];
        this.trickHistory = [];

        // Reset player round states
        this.players.forEach(p => {
            p.hand = [];
            p.passedCards = [];
            p.receivedCards = [];
            p.tricksTaken = [];
            p.roundPoints = 0;
            p.memory = {
                passedCards: [],
                passedTo: null,
                attemptingMoon: false
            };
        });

        // Deal 52 cards
        const deck = new Deck();
        deck.shuffle();
        const hands = deck.dealToPlayers(4);

        for (let i = 0; i < 4; i++) {
            this.players[i].hand = hands[i];
            this.sortPlayerHand(i);
        }

        if (this.onStateChange) this.onStateChange('dealing');

        // Transition to Passing or Playing (if hold round in classic)
        setTimeout(() => {
            if (this.gameMode === HeartsRules.GAME_MODES.CLASSIC && this.passDirection === HeartsRules.PASS_DIRECTIONS.HOLD) {
                this.finishPassingPhase();
            } else {
                this.beginPassingPhase();
            }
        }, 600);
    }

    sortPlayerHand(playerIndex) {
        const suitOrder = { [SUITS.CLUBS]: 0, [SUITS.DIAMONDS]: 1, [SUITS.SPADES]: 2, [SUITS.HEARTS]: 3 };
        this.players[playerIndex].hand.sort((a, b) => {
            if (suitOrder[a.suit] !== suitOrder[b.suit]) {
                return suitOrder[a.suit] - suitOrder[b.suit];
            }
            return a.rank - b.rank;
        });
    }

    // ----------------------------------------------------
    // PASSING PHASE
    // ----------------------------------------------------

    beginPassingPhase() {
        this.currentPhase = HeartsGame.PHASES.PASSING;

        if (this.gameMode === HeartsRules.GAME_MODES.TRIPLE_PASS) {
            this.passDirection = HeartsRules.getTriplePassDirection(this.passStage);
        }

        // Auto-select pass cards for all AI players
        this.players.forEach(p => {
            if (!p.isHuman) {
                p.passedCards = HeartsAI.selectCardsToPass(p, p.hand, this.passDirection, this.settings.aiDifficulty);
            } else {
                p.passedCards = [];
            }
        });

        if (this.onStateChange) this.onStateChange('passing');

        // Check if Pass-and-Play human needs prompt
        this.checkNextHumanPassPrompt();
    }

    checkNextHumanPassPrompt() {
        // If Pass-and-Play with multiple humans, check which human hasn't selected their 3 cards
        const pendingHuman = this.players.find(p => p.isHuman && p.passedCards.length < 3);
        if (pendingHuman && this.humanSeats.length > 1 && this.settings.passAndPlayPrivacy) {
            if (this.onPassStepPrompt) {
                this.onPassStepPrompt(pendingHuman);
            }
        }
    }

    setPlayerPassSelection(playerIndex, cards) {
        const player = this.players[playerIndex];
        if (!player || cards.length !== 3) return false;
        player.passedCards = [...cards];

        // Check if all players have selected their cards
        const allSelected = this.players.every(p => p.passedCards.length === 3);
        if (allSelected) {
            this.executeCardExchange();
        } else {
            this.checkNextHumanPassPrompt();
            if (this.onStateChange) this.onStateChange('passing_update');
        }
        return true;
    }

    executeCardExchange() {
        // Remove passed cards from hands and exchange them
        for (let i = 0; i < 4; i++) {
            const sender = this.players[i];
            const targetIndex = HeartsRules.getPassTargetIndex(i, this.passDirection);
            const receiver = this.players[targetIndex];

            // Record memory of what sender passed to whom
            if (sender.memory) {
                sender.memory.passedCards = [...(sender.memory.passedCards || []), ...sender.passedCards];
                sender.memory.passedTo = targetIndex;
            }

            // Remove passed cards from sender
            sender.hand = sender.hand.filter(c => !sender.passedCards.some(pc => pc.id === c.id));
            receiver.receivedCards = [...sender.passedCards];
        }

        // Add received cards to hands
        for (let i = 0; i < 4; i++) {
            const p = this.players[i];
            p.hand.push(...p.receivedCards);
            this.sortPlayerHand(i);
        }

        if (window.soundEngine) window.soundEngine.playCardPass();

        // Check if Triple Pass mode has more stages remaining (stages 1 and 2 advance to next stage)
        if (this.gameMode === HeartsRules.GAME_MODES.TRIPLE_PASS && this.passStage < 3) {
            const completedStage = this.passStage;
            if (this.onStateChange) this.onStateChange('stage_passed', { completedStage });

            setTimeout(() => {
                this.passStage += 1;
                this.beginPassingPhase();
            }, 1400);
        } else {
            // Passing complete! Transition to playing
            if (this.onStateChange) this.onStateChange('passed');

            setTimeout(() => {
                this.finishPassingPhase();
            }, 1200);
        }
    }

    finishPassingPhase() {
        this.currentPhase = HeartsGame.PHASES.PLAYING;
        this.trickNumber = 1;

        // Player with 2 of Clubs leads first trick
        let starterIndex = 0;
        for (let i = 0; i < 4; i++) {
            if (this.players[i].hand.some(c => c.isTwoOfClubs())) {
                starterIndex = i;
                break;
            }
        }
        this.activePlayerIndex = starterIndex;

        if (this.onStateChange) this.onStateChange('playing');

        // If first player is an AI, trigger AI move
        this.handleTurn();
    }

    // ----------------------------------------------------
    // TRICK PLAYING PHASE
    // ----------------------------------------------------

    handleTurn() {
        if (this.currentPhase !== HeartsGame.PHASES.PLAYING) return;

        const activePlayer = this.players[this.activePlayerIndex];

        if (this.onStateChange) this.onStateChange('turn_start');

        if (!activePlayer.isHuman) {
            // AI Turn with natural delay based on animation speed
            const speedDelay = {
                slow: 1100,
                normal: 650,
                fast: 280,
                instant: 40
            }[this.settings.animationSpeed] || 650;

            setTimeout(() => {
                if (this.currentPhase !== HeartsGame.PHASES.PLAYING) return;
                this.playAITurn();
            }, speedDelay);
        }
    }

    playAITurn() {
        const bot = this.players[this.activePlayerIndex];
        const isFirstTrick = this.trickNumber === 1;
        const gameState = {
            playedCards: this.playedCards,
            trickNumber: this.trickNumber,
            scores: this.players.map(p => p.totalScore),
            players: this.players,
            activePlayerIndex: this.activePlayerIndex,
            botMemory: bot.memory || { passedCards: [], passedTo: null, attemptingMoon: false }
        };

        const chosenCard = HeartsAI.selectCardToPlay(
            bot.hand,
            this.currentTrick,
            this.heartsBroken,
            isFirstTrick,
            gameState,
            this.settings.aiDifficulty
        );

        this.playCard(this.activePlayerIndex, chosenCard);
    }

    playCard(playerIndex, card) {
        if (this.currentPhase !== HeartsGame.PHASES.PLAYING) return false;
        if (playerIndex !== this.activePlayerIndex) return false;

        const player = this.players[playerIndex];
        const isFirstTrick = this.trickNumber === 1;

        // Verify legality
        const isLegal = HeartsRules.isCardPlayable(card, player.hand, this.currentTrick, this.heartsBroken, isFirstTrick);
        if (!isLegal) return false;

        // Check if hearts are broken by this play
        if (card.isHeart() && !this.heartsBroken) {
            this.heartsBroken = true;
        }

        // Play card audio
        if (window.soundEngine) {
            if (card.isQueenOfSpades()) {
                window.soundEngine.playQueenAlert();
            } else {
                window.soundEngine.playCardPlay();
            }
        }

        // Remove card from hand
        player.hand = player.hand.filter(c => c.id !== card.id);
        
        // Add to active trick
        const playRecord = { playerIndex, card };
        this.currentTrick.push(playRecord);
        this.playedCards.push(card);

        if (this.onCardPlayed) {
            this.onCardPlayed(playRecord);
        }

        // Advance to next player or complete trick
        if (this.currentTrick.length === 4) {
            this.completeTrick();
        } else {
            this.activePlayerIndex = (this.activePlayerIndex + 1) % 4;
            this.handleTurn();
        }

        return true;
    }

    completeTrick() {
        const completedTrick = [...this.currentTrick];
        const winnerIndex = HeartsRules.evaluateTrickWinner(completedTrick);
        const trickPoints = HeartsRules.calculatePoints(completedTrick.map(p => p.card));
        
        const winner = this.players[winnerIndex];
        winner.tricksTaken.push(completedTrick);
        winner.roundPoints += trickPoints;

        // Save snapshot for Undo in single-player
        if (this.humanSeats.length === 1) {
            this.trickHistory.push({
                trickNumber: this.trickNumber,
                trick: completedTrick,
                winnerIndex,
                heartsBrokenBefore: this.heartsBroken,
                starterIndex: completedTrick[0].playerIndex,
                playerHands: this.players.map(p => [...p.hand])
            });
        }

        // 1. Notify UI to display all 4 cards and highlight the winning card
        if (this.onTrickComplete) {
            this.onTrickComplete(winnerIndex, completedTrick, trickPoints);
        }

        // Inspection delay: Give user at least 2 full seconds to see all 4 cards on the table
        const inspectDelay = {
            slow: 2800,
            normal: 2200,
            fast: 1500,
            instant: 150
        }[this.settings.animationSpeed] || 2200;

        // 2. Wait 2+ seconds so players can clearly inspect all cards played
        setTimeout(() => {
            // Trigger sweep animation towards winner's station
            if (this.onTrickSweep) {
                this.onTrickSweep(winnerIndex);
            }

            if (window.soundEngine) {
                window.soundEngine.playTrickWin();
            }

            // 3. Allow sweep animation to complete before clearing trick
            const sweepAnimDuration = this.settings.animationSpeed === 'instant' ? 50 : 450;
            setTimeout(() => {
                this.currentTrick = [];
                this.trickNumber += 1;
                this.activePlayerIndex = winnerIndex;

                if (this.trickNumber > 13) {
                    // Round is finished!
                    this.completeRound();
                } else {
                    // Next trick
                    this.handleTurn();
                }
            }, sweepAnimDuration);
        }, inspectDelay);
    }

    // Single-player undo trick
    undoLastTrick() {
        if (this.trickHistory.length === 0 || this.currentPhase !== HeartsGame.PHASES.PLAYING) {
            return false;
        }

        const lastSnapshot = this.trickHistory.pop();
        this.trickNumber = lastSnapshot.trickNumber;
        this.heartsBroken = lastSnapshot.heartsBrokenBefore;
        this.activePlayerIndex = lastSnapshot.starterIndex;
        this.currentTrick = [];

        // Restore cards from the trick back to player hands
        lastSnapshot.trick.forEach(({ playerIndex, card }) => {
            this.players[playerIndex].hand.push(card);
            this.sortPlayerHand(playerIndex);
            // Remove from played cards history
            const idx = this.playedCards.findIndex(c => c.id === card.id);
            if (idx !== -1) this.playedCards.splice(idx, 1);
        });

        // Deduct points and trick from winner
        const winner = this.players[lastSnapshot.winnerIndex];
        winner.tricksTaken.pop();
        winner.roundPoints -= HeartsRules.calculatePoints(lastSnapshot.trick.map(p => p.card));

        if (this.onStateChange) this.onStateChange('undo');
        this.handleTurn();
        return true;
    }

    // ----------------------------------------------------
    // ROUND COMPLETION AND SCORING
    // ----------------------------------------------------

    completeRound() {
        this.currentPhase = HeartsGame.PHASES.ROUND_END;
        const rawPoints = this.players.map(p => p.roundPoints);
        
        // Calculate scores factoring Shoot the Moon
        const { finalScores, moonShooterIndex } = HeartsRules.calculateRoundScoreDeltas(
            rawPoints,
            this.settings.moonRule
        );

        const shotMoon = moonShooterIndex !== null;
        if (shotMoon && window.soundEngine) {
            window.soundEngine.playMoonShot();
        }

        // Apply scores
        for (let i = 0; i < 4; i++) {
            this.players[i].scoreHistory.push(finalScores[i]);
            this.players[i].totalScore += finalScores[i];
        }

        // Check for Game Over condition
        const target = this.settings.targetScore || 100;
        const isGameOver = this.players.some(p => p.totalScore >= target);

        if (this.onRoundComplete) {
            this.onRoundComplete({
                roundNumber: this.roundNumber,
                rawPoints,
                finalScores,
                moonShooterIndex,
                players: this.players,
                isGameOver
            });
        }

        if (isGameOver) {
            this.completeGame(shotMoon);
        }
    }

    completeGame(shotMoon = false) {
        this.currentPhase = HeartsGame.PHASES.GAME_OVER;

        // Winner has the LOWEST score
        let lowestScore = Infinity;
        let winnerIndex = 0;

        for (let i = 0; i < 4; i++) {
            if (this.players[i].totalScore < lowestScore) {
                lowestScore = this.players[i].totalScore;
                winnerIndex = i;
            }
        }

        // Save persistent statistics
        StatsManager.recordGameCompletion(
            winnerIndex,
            this.humanSeats,
            this.players.map(p => p.totalScore),
            shotMoon
        );

        if (window.soundEngine) {
            window.soundEngine.playVictory();
        }

        if (this.onGameOver) {
            this.onGameOver({
                winnerIndex,
                winner: this.players[winnerIndex],
                players: this.players,
                roundsPlayed: this.roundNumber
            });
        }
    }

    nextRound() {
        this.roundNumber += 1;
        this.startNewRound();
    }
}

window.HeartsGame = HeartsGame;
