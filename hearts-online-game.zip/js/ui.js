/**
 * Table UI Controller and View Management
 * MobilityWare-grade presentation, animations, modals, and interaction handling.
 */

class TableUI {
    constructor() {
        this.game = null;
        this.selectedPassCardIds = new Set();
        this.activeHintCard = null;
        this.currentViewingPlayerIndex = 0; // In Pass-and-Play, which human is viewing
        window.tableUI = this;
        
        this.initDOMElements();
        this.bindGlobalEvents();
        this.initOnlineMultiplayer();
        this.applyTheme(StatsManager.loadSettings());
    }

    initDOMElements() {
        // Table & players
        this.tableEl = document.getElementById('poker-table');
        this.centerTrickEl = document.getElementById('center-trick');
        this.playerHandEl = document.getElementById('player-hand');
        this.playerContainers = [
            document.getElementById('player-south'),
            document.getElementById('player-west'),
            document.getElementById('player-north'),
            document.getElementById('player-east')
        ];

        // Banner and notification overlays
        this.statusBannerEl = document.getElementById('status-banner');
        this.passControlsEl = document.getElementById('pass-controls');
        this.btnConfirmPass = document.getElementById('btn-confirm-pass');
        this.passDirectionText = document.getElementById('pass-direction-text');
        this.hintBoxEl = document.getElementById('hint-tooltip');

        // Header controls
        this.btnUndo = document.getElementById('btn-undo');
        this.btnHint = document.getElementById('btn-hint');
        this.btnScoreboard = document.getElementById('btn-scoreboard');
        this.btnSettings = document.getElementById('btn-settings');
        this.btnStats = document.getElementById('btn-stats');
        this.btnRules = document.getElementById('btn-rules');
        this.btnNewGame = document.getElementById('btn-new-game');
        this.btnToggleSound = document.getElementById('btn-toggle-sound');
        this.btnOnline = document.getElementById('btn-online');

        // Online HUD
        this.onlineHudEl = document.getElementById('online-hud');
        this.hudRoomCodeEl = document.getElementById('hud-room-code');
        this.btnHudCopy = document.getElementById('btn-hud-copy');
        this.hudChatInput = document.getElementById('hud-chat-input');
        this.btnSendChat = document.getElementById('btn-send-chat');

        // Modals
        this.modalScoreboard = document.getElementById('modal-scoreboard');
        this.modalSettings = document.getElementById('modal-settings');
        this.modalStats = document.getElementById('modal-stats');
        this.modalRules = document.getElementById('modal-rules');
        this.modalNewGame = document.getElementById('modal-new-game');
        this.modalGameOver = document.getElementById('modal-game-over');
        this.modalMoonShot = document.getElementById('modal-moon-shot');
        this.privacyCurtain = document.getElementById('privacy-curtain');
        this.modalOnline = document.getElementById('modal-online');
    }

    bindGlobalEvents() {
        // Sound toggle
        if (this.btnToggleSound) {
            this.btnToggleSound.addEventListener('click', () => {
                const settings = StatsManager.loadSettings();
                settings.soundEnabled = !settings.soundEnabled;
                StatsManager.saveSettings(settings);
                window.soundEngine.setMuted(!settings.soundEnabled);
                this.updateSoundButtonUI(settings.soundEnabled);
            });
        }

        // Pass Confirm
        if (this.btnConfirmPass) {
            this.btnConfirmPass.addEventListener('click', () => {
                this.handleConfirmPass();
            });
        }

        // Hint Button
        if (this.btnHint) {
            this.btnHint.addEventListener('click', () => {
                this.handleShowHint();
            });
        }

        // Undo Button
        if (this.btnUndo) {
            this.btnUndo.addEventListener('click', () => {
                if (this.game) {
                    this.game.undoLastTrick();
                }
            });
        }

        // Modal triggers
        this.btnScoreboard?.addEventListener('click', () => this.showScoreboardModal());
        this.btnSettings?.addEventListener('click', () => this.showSettingsModal());
        this.btnStats?.addEventListener('click', () => this.showStatsModal());
        this.btnRules?.addEventListener('click', () => this.showRulesModal());
        this.btnNewGame?.addEventListener('click', () => this.showNewGameModal());

        // Close modal buttons (data-close)
        document.querySelectorAll('[data-close-modal]').forEach(btn => {
            btn.addEventListener('click', () => {
                const modalId = btn.getAttribute('data-close-modal');
                const modal = document.getElementById(modalId);
                if (modal) modal.classList.add('hidden');
            });
        });

        // Settings change handlers
        document.getElementById('setting-theme')?.addEventListener('change', (e) => {
            const settings = StatsManager.loadSettings();
            settings.tableTheme = e.target.value;
            StatsManager.saveSettings(settings);
            this.applyTheme(settings);
        });

        document.getElementById('setting-card-back')?.addEventListener('change', (e) => {
            const settings = StatsManager.loadSettings();
            settings.cardBackTheme = e.target.value;
            StatsManager.saveSettings(settings);
            this.renderAllHands();
        });

        document.getElementById('setting-speed')?.addEventListener('change', (e) => {
            const settings = StatsManager.loadSettings();
            settings.animationSpeed = e.target.value;
            StatsManager.saveSettings(settings);
            if (this.game) this.game.settings.animationSpeed = e.target.value;
        });

        document.getElementById('setting-target-score')?.addEventListener('change', (e) => {
            const settings = StatsManager.loadSettings();
            settings.targetScore = parseInt(e.target.value, 10);
            StatsManager.saveSettings(settings);
            if (this.game) this.game.settings.targetScore = settings.targetScore;
        });

        document.getElementById('setting-difficulty')?.addEventListener('change', (e) => {
            const settings = StatsManager.loadSettings();
            settings.aiDifficulty = e.target.value;
            StatsManager.saveSettings(settings);
            if (this.game) this.game.settings.aiDifficulty = e.target.value;
        });

        // Privacy curtain reveal button
        document.getElementById('btn-reveal-hand')?.addEventListener('click', () => {
            this.privacyCurtain.classList.add('hidden');
            this.renderAll();
        });

        // Start game form submit in New Game modal
        document.getElementById('form-new-game')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleStartGameFromModal();
        });
    }

    applyTheme(settings) {
        if (!this.tableEl) return;
        this.tableEl.classList.remove('theme-green', 'theme-navy', 'theme-crimson', 'theme-wood');
        this.tableEl.classList.add(`theme-${settings.tableTheme || 'green'}`);
        this.updateSoundButtonUI(settings.soundEnabled);
    }

    updateSoundButtonUI(enabled) {
        if (!this.btnToggleSound) return;
        this.btnToggleSound.innerHTML = enabled ? '🔊' : '🔇';
        this.btnToggleSound.title = enabled ? 'Sound On' : 'Sound Off';
    }

    // Converts visual station index (0=South, 1=West, 2=North, 3=East) to Player Index
    getPlayerIndexForStation(stationIndex) {
        if (!this.game) return stationIndex;
        return (this.currentViewingPlayerIndex + stationIndex) % 4;
    }

    // Converts Player Index to visual station index (0=South, 1=West, 2=North, 3=East)
    getStationForPlayerIndex(playerIndex) {
        if (!this.game) return playerIndex;
        return (playerIndex - this.currentViewingPlayerIndex + 4) % 4;
    }

    // Attach to game instance and register callbacks
    bindGame(game) {
        this.game = game;
        this.currentViewingPlayerIndex = game.humanSeats[0] || 0;

        game.onStateChange = (event, data) => {
            if (event === 'dealing') {
                // Host sends each connected guest their private hand
                if (window.heartsNetwork && window.heartsNetwork.isHost && window.heartsNetwork.isConnected) {
                    for (const [seatStr, conn] of Object.entries(window.heartsNetwork.guestConnections)) {
                        const seat = parseInt(seatStr);
                        const guestHand = this.game.players[seat].hand.map(c => ({ suit: c.suit, rank: c.rank, id: c.id }));
                        window.heartsNetwork.sendToGuest(seat, {
                            type: 'round_dealt',
                            myHand: guestHand,
                            passDirection: this.game.passDirection,
                            passStage: this.game.passStage,
                            gameMode: this.game.gameMode,
                            roundNumber: this.game.roundNumber,
                            scores: this.game.players.map(p => p.totalScore),
                            playerNames: this.game.players.map(p => p.name)
                        });
                    }
                }
            } else if (event === 'turn_start' && this.game.currentPhase === HeartsGame.PHASES.PLAYING) {
                // Host broadcasts turn update
                if (window.heartsNetwork && window.heartsNetwork.isHost && window.heartsNetwork.isConnected) {
                    window.heartsNetwork.broadcastToGuests({
                        type: 'turn_update',
                        activePlayerIndex: this.game.activePlayerIndex,
                        currentTrick: this.game.currentTrick.map(p => ({ playerIndex: p.playerIndex, card: { suit: p.card.suit, rank: p.card.rank, id: p.card.id } })),
                        heartsBroken: this.game.heartsBroken,
                        trickNumber: this.game.trickNumber
                    });
                }

                const activePlayer = this.game.players[this.game.activePlayerIndex];
                if (activePlayer.isHuman && this.game.humanSeats.length > 1 && this.currentViewingPlayerIndex !== activePlayer.index) {
                    this.currentViewingPlayerIndex = activePlayer.index;
                    if (this.game.settings.passAndPlayPrivacy) {
                        this.showPrivacyCurtainFor(activePlayer, "It's your turn to play!");
                        return;
                    }
                }
            } else if (event === 'stage_passed') {
                const stageName = data.completedStage === 1 ? 'Left' : (data.completedStage === 2 ? 'Front' : 'Right');
                this.showToast(`Stage ${data.completedStage}/3 (${stageName}) passed! Next pass starting.`);
                this.selectedPassCardIds.clear();

                // Host sends updated hand and received cards to guests
                if (window.heartsNetwork && window.heartsNetwork.isHost && window.heartsNetwork.isConnected) {
                    for (const [seatStr, conn] of Object.entries(window.heartsNetwork.guestConnections)) {
                        const seat = parseInt(seatStr);
                        const guestHand = this.game.players[seat].hand.map(c => ({ suit: c.suit, rank: c.rank, id: c.id }));
                        const received = (this.game.players[seat].receivedCards || []).map(c => ({ suit: c.suit, rank: c.rank, id: c.id }));
                        window.heartsNetwork.sendToGuest(seat, {
                            type: 'pass_exchanged',
                            myHand: guestHand,
                            receivedCards: received,
                            passStage: this.game.passStage,
                            nextPhase: this.game.currentPhase
                        });
                    }
                }
            } else if (event === 'passed') {
                this.selectedPassCardIds.clear();
                this.showToast('Passing phase complete! Starting round.');

                // Host sends final exchanged hands to guests
                if (window.heartsNetwork && window.heartsNetwork.isHost && window.heartsNetwork.isConnected) {
                    for (const [seatStr, conn] of Object.entries(window.heartsNetwork.guestConnections)) {
                        const seat = parseInt(seatStr);
                        const guestHand = this.game.players[seat].hand.map(c => ({ suit: c.suit, rank: c.rank, id: c.id }));
                        const received = (this.game.players[seat].receivedCards || []).map(c => ({ suit: c.suit, rank: c.rank, id: c.id }));
                        window.heartsNetwork.sendToGuest(seat, {
                            type: 'pass_exchanged',
                            myHand: guestHand,
                            receivedCards: received,
                            passStage: this.game.passStage,
                            nextPhase: this.game.currentPhase
                        });
                    }
                }
            }
            this.renderAll();
            this.updateStatusBanner();
        };

        game.onCardPlayed = ({ playerIndex, card }) => {
            this.renderCenterTrick();
            this.renderAllHands();
            this.updatePlayerBadges();
            this.hideHint();

            // Host broadcasts card played
            if (window.heartsNetwork && window.heartsNetwork.isHost && window.heartsNetwork.isConnected) {
                window.heartsNetwork.broadcastToGuests({
                    type: 'card_played',
                    playerIndex,
                    card: { suit: card.suit, rank: card.rank, id: card.id },
                    heartsBroken: this.game.heartsBroken,
                    activePlayerIndex: this.game.activePlayerIndex
                });
            }
        };

        game.onTrickComplete = (winnerIndex, trick, points) => {
            // Find winning card from trick
            const ledSuit = trick[0].card.suit;
            let highestRank = -1;
            let winningPlay = trick[0];
            for (const play of trick) {
                if (play.card.suit === ledSuit && play.card.rank > highestRank) {
                    highestRank = play.card.rank;
                    winningPlay = play;
                }
            }

            // Render all 4 cards, prominently marking the winning card
            this.renderCenterTrick(winningPlay.card.id);
            this.updatePlayerBadges();

            const winner = this.game.players[winnerIndex];
            const ptText = points > 0 ? ` (+${points} pts)` : ' (0 pts)';
            this.showToast(`${winner.name} won the trick!${ptText}`, 2200);

            if (this.statusBannerEl) {
                this.statusBannerEl.textContent = `Trick ${this.game.trickNumber}/13: ${winner.name} takes the trick!${ptText}`;
            }

            // Host broadcasts trick complete
            if (window.heartsNetwork && window.heartsNetwork.isHost && window.heartsNetwork.isConnected) {
                window.heartsNetwork.broadcastToGuests({
                    type: 'trick_complete',
                    winnerIndex,
                    trick: trick.map(p => ({ playerIndex: p.playerIndex, card: { suit: p.card.suit, rank: p.card.rank, id: p.card.id } })),
                    points
                });
            }
        };

        game.onTrickSweep = (winnerIndex) => {
            this.sweepTrickCards(winnerIndex);

            // Host broadcasts trick sweep
            if (window.heartsNetwork && window.heartsNetwork.isHost && window.heartsNetwork.isConnected) {
                window.heartsNetwork.broadcastToGuests({
                    type: 'trick_sweep',
                    winnerIndex
                });
            }
        };

        game.onRoundComplete = (roundData) => {
            this.showRoundSummary(roundData);

            // Host broadcasts round complete
            if (window.heartsNetwork && window.heartsNetwork.isHost && window.heartsNetwork.isConnected) {
                window.heartsNetwork.broadcastToGuests({
                    type: 'round_complete',
                    roundData,
                    totalScores: this.game.players.map(p => p.totalScore)
                });
            }
        };

        game.onGameOver = (gameOverData) => {
            this.showGameOverModal(gameOverData);

            // Host broadcasts game over
            if (window.heartsNetwork && window.heartsNetwork.isHost && window.heartsNetwork.isConnected) {
                window.heartsNetwork.broadcastToGuests({
                    type: 'game_over',
                    gameOverData
                });
            }
        };

        game.onPassStepPrompt = (pendingHuman) => {
            this.currentViewingPlayerIndex = pendingHuman.index;
            const stageText = this.game.gameMode === HeartsRules.GAME_MODES.TRIPLE_PASS
                ? `Triple Pass (Stage ${this.game.passStage}/3): Pick 3 cards`
                : 'Pick 3 cards to pass';
            this.showPrivacyCurtainFor(pendingHuman, stageText);
        };

        this.renderAll();
        this.updateStatusBanner();
    }

    renderAll() {
        if (!this.game) return;
        this.renderAllHands();
        this.renderCenterTrick();
        this.updatePlayerBadges();
        this.updateControls();
    }

    renderAllHands() {
        for (let station = 0; station < 4; station++) {
            const playerIndex = this.getPlayerIndexForStation(station);
            this.renderStationHand(station, playerIndex);
        }
    }

    renderPlayerHand(playerIndex) {
        if (!this.game) return;
        const station = this.getStationForPlayerIndex(playerIndex);
        this.renderStationHand(station, playerIndex);
    }

    renderStationHand(stationIndex, playerIndex) {
        const player = this.game.players[playerIndex];
        const isCurrentViewingHuman = stationIndex === 0 && player.isHuman;
        const container = this.playerContainers[stationIndex];
        if (!container || !player) return;

        const cardsContainer = container.querySelector('.hand-cards');
        if (!cardsContainer) return;

        cardsContainer.innerHTML = '';

        if (isCurrentViewingHuman) {
            // Render face-up cards for the active human player
            const isPassingPhase = this.game.currentPhase === HeartsGame.PHASES.PASSING;
            const isMyTurn = this.game.currentPhase === HeartsGame.PHASES.PLAYING && this.game.activePlayerIndex === playerIndex;
            const isFirstTrick = this.game.trickNumber === 1;

            player.hand.forEach((card, idx) => {
                const cardEl = document.createElement('div');
                cardEl.className = 'card-wrapper card-interactive';
                cardEl.dataset.cardId = card.id;

                const isSelectedForPass = this.selectedPassCardIds.has(card.id);
                if (isSelectedForPass) {
                    cardEl.classList.add('selected-pass');
                }

                // Highlight cards received from previous pass stage in Triple Pass mode
                if (isPassingPhase && player.receivedCards && player.receivedCards.some(rc => rc.id === card.id)) {
                    cardEl.classList.add('newly-received');
                }

                // If trick play, indicate if card is legal to play
                if (isMyTurn) {
                    const isLegal = HeartsRules.isCardPlayable(card, player.hand, this.game.currentTrick, this.game.heartsBroken, isFirstTrick);
                    if (isLegal) {
                        cardEl.classList.add('playable');
                    } else {
                        cardEl.classList.add('unplayable');
                    }
                }

                if (this.activeHintCard && this.activeHintCard.id === card.id) {
                    cardEl.classList.add('hinted');
                }

                cardEl.innerHTML = CardRenderer.renderCardFace(card);

                // Add pass badge if selected
                if (isSelectedForPass) {
                    const passBadge = document.createElement('div');
                    passBadge.className = 'pass-badge-indicator';
                    passBadge.textContent = '▲ PASS';
                    cardEl.appendChild(passBadge);
                }

                // Click event with event stopping
                cardEl.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.handleCardClick(playerIndex, card);
                });

                cardsContainer.appendChild(cardEl);
            });
        } else {
            // Render face-down cards for AI or hidden human players
            const cardBackSvg = CardRenderer.renderCardBack(this.game.settings.cardBackTheme);
            const count = player.hand.length;

            // Render a stacked fan of card backs
            for (let i = 0; i < Math.min(count, 13); i++) {
                const cardEl = document.createElement('div');
                cardEl.className = 'card-wrapper card-facedown';
                cardEl.innerHTML = cardBackSvg;
                cardsContainer.appendChild(cardEl);
            }

            // Card count badge
            const countBadge = container.querySelector('.card-count-badge');
            if (countBadge) {
                countBadge.textContent = `${count} cards`;
                countBadge.style.display = count > 0 ? 'inline-block' : 'none';
            }
        }
    }

    renderCenterTrick(winningCardId = null) {
        if (!this.centerTrickEl || !this.game) return;

        const trick = this.game.currentTrick;
        if (trick.length === 0) {
            this.centerTrickEl.innerHTML = '';
            return;
        }

        const positions = ['pos-south', 'pos-west', 'pos-north', 'pos-east'];

        // Only append cards that are not already on the table.
        // Existing cards stay completely still and never glitch/re-animate!
        trick.forEach(({ playerIndex, card }, idx) => {
            let cardEl = this.centerTrickEl.querySelector(`[data-card-id="${card.id}"]`);
            if (!cardEl) {
                const station = this.getStationForPlayerIndex(playerIndex);
                cardEl = document.createElement('div');
                cardEl.className = `trick-card ${positions[station]}`;
                cardEl.dataset.cardId = card.id;
                cardEl.innerHTML = CardRenderer.renderCardFace(card);
                this.centerTrickEl.appendChild(cardEl);
            }

            // Highlight the winning card once all 4 cards have landed
            if (winningCardId && card.id === winningCardId) {
                cardEl.classList.add('trick-winning-card');
                if (!cardEl.querySelector('.trick-winner-badge')) {
                    const badge = document.createElement('div');
                    badge.className = 'trick-winner-badge';
                    badge.textContent = '★ WINNER';
                    cardEl.appendChild(badge);
                }
            }
        });
    }

    sweepTrickCards(winnerIndex) {
        const positions = ['south', 'west', 'north', 'east'];
        const station = this.getStationForPlayerIndex(winnerIndex);
        
        // Sweep animation towards winner's station
        const trickCards = this.centerTrickEl.querySelectorAll('.trick-card');
        trickCards.forEach(c => {
            c.classList.add(`sweep-to-${positions[station]}`);
        });
    }

    updatePlayerBadges() {
        if (!this.game) return;

        this.playerContainers.forEach((container, station) => {
            const playerIndex = this.getPlayerIndexForStation(station);
            const player = this.game.players[playerIndex];
            if (!container || !player) return;

            const nameEl = container.querySelector('.player-name');
            const roundScoreEl = container.querySelector('.player-round-score');
            const totalScoreEl = container.querySelector('.player-total-score');
            const turnIndicator = container.querySelector('.turn-glow');
            const avatarEl = container.querySelector('.avatar-circle');

            if (nameEl) nameEl.textContent = player.name;
            if (avatarEl) avatarEl.textContent = player.avatar;
            if (roundScoreEl) roundScoreEl.textContent = `${player.roundPoints} pts this round`;
            if (totalScoreEl) totalScoreEl.textContent = `Total: ${player.totalScore}`;

            // Active turn glow
            const isTurn = this.game.currentPhase === HeartsGame.PHASES.PLAYING && this.game.activePlayerIndex === playerIndex;
            if (turnIndicator) {
                turnIndicator.classList.toggle('active-turn', isTurn);
            }
        });
    }

    updateControls() {
        if (!this.game) return;

        const isPlaying = this.game.currentPhase === HeartsGame.PHASES.PLAYING;
        const isPassing = this.game.currentPhase === HeartsGame.PHASES.PASSING;
        const isSinglePlayer = this.game.humanSeats.length === 1;

        if (this.btnUndo) {
            this.btnUndo.disabled = !isPlaying || !isSinglePlayer || this.game.trickHistory.length === 0;
        }

        if (this.btnHint) {
            this.btnHint.disabled = !isPlaying || this.game.activePlayerIndex !== this.currentViewingPlayerIndex;
        }

        if (this.passControlsEl) {
            this.passControlsEl.classList.toggle('hidden', !isPassing);
            if (isPassing) {
                let dirLabel;
                if (this.game.gameMode === HeartsRules.GAME_MODES.TRIPLE_PASS) {
                    dirLabel = HeartsRules.getTriplePassLabel(this.game.passStage);
                } else {
                    dirLabel = HeartsRules.getPassDirectionLabel(this.game.passDirection);
                }
                this.passDirectionText.textContent = dirLabel;
                this.btnConfirmPass.disabled = this.selectedPassCardIds.size !== 3;
                this.btnConfirmPass.textContent = `Pass 3 Cards (${this.selectedPassCardIds.size}/3)`;
            }
        }
    }

    updateStatusBanner() {
        if (!this.statusBannerEl || !this.game) return;

        switch(this.game.currentPhase) {
            case HeartsGame.PHASES.DEALING:
                this.statusBannerEl.textContent = `Round ${this.game.roundNumber}: Shuffling & Dealing...`;
                break;
            case HeartsGame.PHASES.PASSING:
                let dirLabel;
                if (this.game.gameMode === HeartsRules.GAME_MODES.TRIPLE_PASS) {
                    dirLabel = HeartsRules.getTriplePassLabel(this.game.passStage);
                } else {
                    dirLabel = HeartsRules.getPassDirectionLabel(this.game.passDirection);
                }
                this.statusBannerEl.textContent = `Round ${this.game.roundNumber}: ${dirLabel}`;
                break;
            case HeartsGame.PHASES.PLAYING:
                const activeP = this.game.players[this.game.activePlayerIndex];
                const leadText = this.game.currentTrick.length === 0 ? 'to lead' : 'to play';
                const heartsText = this.game.heartsBroken ? ' | Hearts Broken ♥' : '';
                this.statusBannerEl.textContent = `Trick ${this.game.trickNumber}/13: ${activeP.name}'s turn ${leadText}${heartsText}`;
                break;
            case HeartsGame.PHASES.ROUND_END:
                this.statusBannerEl.textContent = `Round ${this.game.roundNumber} Complete!`;
                break;
            case HeartsGame.PHASES.GAME_OVER:
                this.statusBannerEl.textContent = `Game Over!`;
                break;
        }
    }

    // ----------------------------------------------------
    // USER INTERACTIONS
    // ----------------------------------------------------

    handleCardClick(playerIndex, card) {
        // Online Guest routing
        if (window.heartsNetwork && window.heartsNetwork.isConnected && !window.heartsNetwork.isHost) {
            // Passing phase for Online Guest
            if (this.onlineIsPassingPhase) {
                if (window.soundEngine) window.soundEngine.playCardSelect();
                if (this.selectedPassCardIds.has(card.id)) {
                    this.selectedPassCardIds.delete(card.id);
                } else {
                    if (this.selectedPassCardIds.size < 3) {
                        this.selectedPassCardIds.add(card.id);
                    } else {
                        this.showToast('You can only pass 3 cards. Click a selected card to unselect it.');
                    }
                }
                this.renderOnlineGuestHand();
                if (this.btnConfirmPass) {
                    this.btnConfirmPass.disabled = this.selectedPassCardIds.size !== 3;
                    this.btnConfirmPass.textContent = `Pass 3 Cards (${this.selectedPassCardIds.size}/3)`;
                }
                return;
            }

            // Playing phase for Online Guest
            if (this.onlineActivePlayerIndex !== playerIndex) {
                this.showToast("It's not your turn!");
                return;
            }

            const isFirstTrick = (this.onlineTrickNumber || 1) === 1;
            const currentTrick = this.onlineCurrentTrick || [];
            const isLegal = HeartsRules.isCardPlayable(card, this.onlineGuestHand, currentTrick, this.onlineHeartsBroken, isFirstTrick);

            if (!isLegal) {
                if (isFirstTrick && currentTrick.length === 0) {
                    this.showToast('You must lead the 2 of Clubs!');
                } else if (card.isHeart() && !this.onlineHeartsBroken && currentTrick.length === 0) {
                    this.showToast('Hearts have not been broken yet!');
                } else {
                    const ledSuit = currentTrick[0].card.suit;
                    this.showToast(`You must follow suit (${ledSuit})!`);
                }
                return;
            }

            // Send play to Host
            window.heartsNetwork.playCard(card);
            return;
        }

        if (!this.game) return;

        // If Passing phase
        if (this.game.currentPhase === HeartsGame.PHASES.PASSING) {
            if (window.soundEngine) window.soundEngine.playCardSelect();
            if (this.selectedPassCardIds.has(card.id)) {
                this.selectedPassCardIds.delete(card.id);
            } else {
                if (this.selectedPassCardIds.size < 3) {
                    this.selectedPassCardIds.add(card.id);
                } else {
                    this.showToast('You can only pass 3 cards. Click a selected card to unselect it.');
                }
            }
            this.renderPlayerHand(playerIndex);
            this.updateControls();
            return;
        }

        // If Playing phase
        if (this.game.currentPhase === HeartsGame.PHASES.PLAYING) {
            if (this.game.activePlayerIndex !== playerIndex) {
                this.showToast("It's not your turn!");
                return;
            }

            const isFirstTrick = this.game.trickNumber === 1;
            const player = this.game.players[playerIndex];
            const isLegal = HeartsRules.isCardPlayable(card, player.hand, this.game.currentTrick, this.game.heartsBroken, isFirstTrick);

            if (!isLegal) {
                if (isFirstTrick && this.game.currentTrick.length === 0) {
                    this.showToast('You must lead the 2 of Clubs!');
                } else if (card.isHeart() && !this.game.heartsBroken && this.game.currentTrick.length === 0) {
                    this.showToast('Hearts have not been broken yet!');
                } else {
                    const ledSuit = this.game.currentTrick[0].card.suit;
                    this.showToast(`You must follow suit (${ledSuit})!`);
                }
                return;
            }

            // Execute play
            this.game.playCard(playerIndex, card);
        }
    }

    handleConfirmPass() {
        if (this.selectedPassCardIds.size !== 3) return;

        // Online Guest routing
        if (window.heartsNetwork && window.heartsNetwork.isConnected && !window.heartsNetwork.isHost) {
            const selectedCards = this.onlineGuestHand.filter(c => this.selectedPassCardIds.has(c.id));
            this.selectedPassCardIds.clear();
            window.heartsNetwork.submitPassCards(selectedCards);
            if (this.passControlsEl) this.passControlsEl.classList.add('hidden');
            if (this.statusBannerEl) this.statusBannerEl.textContent = 'Cards passed! Waiting for other players...';
            this.renderOnlineGuestHand();
            return;
        }

        const player = this.game.players[this.currentViewingPlayerIndex];
        const selectedCards = player.hand.filter(c => this.selectedPassCardIds.has(c.id));
        this.selectedPassCardIds.clear();

        this.game.setPlayerPassSelection(this.currentViewingPlayerIndex, selectedCards);
    }

    handleShowHint() {
        if (!this.game || this.game.currentPhase !== HeartsGame.PHASES.PLAYING) return;
        const player = this.game.players[this.currentViewingPlayerIndex];
        const isFirstTrick = this.game.trickNumber === 1;

        const hint = HeartsAI.getHint(
            player.hand,
            this.game.currentTrick,
            this.game.heartsBroken,
            isFirstTrick,
            {
                playedCards: this.game.playedCards,
                trickNumber: this.game.trickNumber,
                players: this.game.players,
                activePlayerIndex: this.currentViewingPlayerIndex,
                botMemory: player.memory || { passedCards: [], passedTo: null, attemptingMoon: false }
            }
        );

        this.activeHintCard = hint.card;
        this.renderPlayerHand(this.currentViewingPlayerIndex);

        if (this.hintBoxEl) {
            this.hintBoxEl.innerHTML = `<strong>💡 Tactical Hint:</strong> ${hint.reason}`;
            this.hintBoxEl.classList.remove('hidden');
        }
    }

    hideHint() {
        this.activeHintCard = null;
        if (this.hintBoxEl) {
            this.hintBoxEl.classList.add('hidden');
        }
    }

    showToast(message, duration = 2200) {
        let toast = document.getElementById('game-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'game-toast';
            toast.className = 'game-toast';
            document.body.appendChild(toast);
        }
        toast.textContent = message;
        toast.classList.add('show');
        clearTimeout(this.toastTimer);
        this.toastTimer = setTimeout(() => {
            toast.classList.remove('show');
        }, duration);
    }

    showPrivacyCurtainFor(player, message) {
        if (!this.privacyCurtain) return;
        this.currentViewingPlayerIndex = player.index;
        document.getElementById('curtain-player-name').textContent = player.name;
        document.getElementById('curtain-instruction').textContent = message || 'Tap below when ready to see your hand.';
        this.privacyCurtain.classList.remove('hidden');
    }

    // ----------------------------------------------------
    // MODALS
    // ----------------------------------------------------

    showScoreboardModal() {
        if (!this.game || !this.modalScoreboard) return;
        const tbody = document.getElementById('scoreboard-table-body');
        const headers = document.querySelectorAll('.scoreboard-player-header');
        
        // Update player headers
        this.game.players.forEach((p, idx) => {
            if (headers[idx]) headers[idx].textContent = p.name;
        });

        tbody.innerHTML = '';
        const roundsCount = this.game.players[0].scoreHistory.length;

        for (let r = 0; r < roundsCount; r++) {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="font-bold">Round ${r + 1}</td>
                <td>${this.game.players[0].scoreHistory[r]}</td>
                <td>${this.game.players[1].scoreHistory[r]}</td>
                <td>${this.game.players[2].scoreHistory[r]}</td>
                <td>${this.game.players[3].scoreHistory[r]}</td>
            `;
            tbody.appendChild(tr);
        }

        // Totals row
        const totalRow = document.createElement('tr');
        totalRow.className = 'bg-amber-100 font-extrabold text-amber-900 border-t-2 border-amber-300';
        totalRow.innerHTML = `
            <td>TOTAL</td>
            <td>${this.game.players[0].totalScore}</td>
            <td>${this.game.players[1].totalScore}</td>
            <td>${this.game.players[2].totalScore}</td>
            <td>${this.game.players[3].totalScore}</td>
        `;
        tbody.appendChild(totalRow);

        this.modalScoreboard.classList.remove('hidden');
    }

    showRoundSummary(roundData) {
        if (roundData.moonShooterIndex !== null) {
            const shooter = this.game.players[roundData.moonShooterIndex];
            const moonModal = document.getElementById('modal-moon-shot');
            if (moonModal) {
                document.getElementById('moon-shooter-name').textContent = `${shooter.name} Shot the Moon! 🌕`;
                moonModal.classList.remove('hidden');
            }
        }

        setTimeout(() => {
            this.showScoreboardModal();
            const nextRoundBtn = document.getElementById('btn-next-round');
            if (nextRoundBtn) {
                nextRoundBtn.classList.remove('hidden');
                nextRoundBtn.onclick = () => {
                    this.modalScoreboard.classList.add('hidden');
                    nextRoundBtn.classList.add('hidden');
                    this.game.nextRound();
                };
            }
        }, roundData.moonShooterIndex !== null ? 2500 : 800);
    }

    showGameOverModal(data) {
        if (!this.modalGameOver) return;
        const winner = data.winner;
        document.getElementById('game-over-title').textContent = `${winner.name} Wins! 🏆`;
        document.getElementById('game-over-subtitle').textContent = `With a winning score of ${winner.totalScore} points!`;

        const standingsList = document.getElementById('game-over-standings');
        standingsList.innerHTML = '';

        const sorted = [...this.game.players].sort((a, b) => a.totalScore - b.totalScore);
        const medals = ['🥇', '🥈', '🥉', '4️⃣'];

        sorted.forEach((p, idx) => {
            const li = document.createElement('li');
            li.className = 'flex justify-between items-center py-2 border-b border-slate-200';
            li.innerHTML = `
                <div class="flex items-center gap-2">
                    <span class="text-xl">${medals[idx]}</span>
                    <span class="font-bold">${p.name}</span>
                </div>
                <span class="font-mono text-lg font-bold">${p.totalScore} pts</span>
            `;
            standingsList.appendChild(li);
        });

        document.getElementById('btn-play-again').onclick = () => {
            this.modalGameOver.classList.add('hidden');
            this.game.startNewGame();
        };

        this.modalGameOver.classList.remove('hidden');
    }

    showStatsModal() {
        if (!this.modalStats) return;
        const stats = StatsManager.loadStats();
        
        document.getElementById('stat-games-played').textContent = stats.gamesPlayed;
        document.getElementById('stat-games-won').textContent = stats.gamesWon;
        const winRate = stats.gamesPlayed > 0 ? Math.round((stats.gamesWon / stats.gamesPlayed) * 100) : 0;
        document.getElementById('stat-win-rate').textContent = `${winRate}%`;
        document.getElementById('stat-moon-shots').textContent = stats.moonShots;
        document.getElementById('stat-best-score').textContent = stats.bestScore !== null ? stats.bestScore : '-';

        const historyEl = document.getElementById('stat-recent-matches');
        if (historyEl) {
            historyEl.innerHTML = '';
            stats.recentMatches.forEach(m => {
                const div = document.createElement('div');
                div.className = `p-2 rounded text-sm flex justify-between ${m.isWin ? 'bg-emerald-50 text-emerald-800' : 'bg-slate-50 text-slate-800'}`;
                div.innerHTML = `
                    <span>${m.date} - Winner: <strong>${m.winner}</strong></span>
                    <span>Scores: [${m.scores.join(', ')}]</span>
                `;
                historyEl.appendChild(div);
            });
        }

        this.modalStats.classList.remove('hidden');
    }

    showSettingsModal() {
        if (!this.modalSettings) return;
        const s = StatsManager.loadSettings();
        document.getElementById('setting-theme').value = s.tableTheme;
        document.getElementById('setting-card-back').value = s.cardBackTheme;
        document.getElementById('setting-speed').value = s.animationSpeed;
        document.getElementById('setting-target-score').value = s.targetScore;
        document.getElementById('setting-difficulty').value = s.aiDifficulty;
        this.modalSettings.classList.remove('hidden');
    }

    showRulesModal() {
        if (!this.modalRules) return;
        this.modalRules.classList.remove('hidden');
    }

    showNewGameModal() {
        if (!this.modalNewGame) return;
        this.modalNewGame.classList.remove('hidden');
    }

    handleStartGameFromModal() {
        const playerMode = document.querySelector('input[name="game-mode"]:checked').value;
        const gameVariant = document.querySelector('input[name="game-variant"]:checked')?.value || HeartsRules.GAME_MODES.CLASSIC;
        let humanSeats = [0];
        let playerNames = ['You', 'West Bot', 'North Bot', 'East Bot'];

        if (playerMode === 'pass-and-play') {
            const count = parseInt(document.getElementById('select-human-count').value, 10);
            humanSeats = [];
            for (let i = 0; i < count; i++) {
                humanSeats.push(i);
                playerNames[i] = `Player ${i + 1}`;
            }
        }

        this.modalNewGame.classList.add('hidden');

        // Create new game with selected mode and options
        const newGame = new HeartsGame({
            gameMode: gameVariant,
            humanSeats,
            playerNames
        });
        this.bindGame(newGame);
        newGame.startNewGame();
    }

    // =========================================================================
    // ONLINE MULTIPLAYER CONTROLLER
    // =========================================================================

    initOnlineMultiplayer() {
        if (!window.heartsNetwork) return;

        // Header button
        if (this.btnOnline) {
            this.btnOnline.addEventListener('click', () => {
                this.showOnlineModal({ tab: window.heartsNetwork.isConnected ? 'lobby' : 'create' });
            });
        }

        // Tabs
        const tabCreate = document.getElementById('tab-btn-create');
        const tabJoin = document.getElementById('tab-btn-join');
        const tabLobby = document.getElementById('tab-btn-lobby');
        const viewCreate = document.getElementById('view-create-room');
        const viewJoin = document.getElementById('view-join-room');
        const viewLobby = document.getElementById('view-lobby');

        tabCreate?.addEventListener('click', () => {
            tabCreate.classList.add('active');
            tabJoin.classList.remove('active');
            tabLobby?.classList.remove('active');
            viewCreate.classList.remove('hidden');
            viewJoin.classList.add('hidden');
            viewLobby.classList.add('hidden');
        });

        tabJoin?.addEventListener('click', () => {
            tabJoin.classList.add('active');
            tabCreate.classList.remove('active');
            tabLobby?.classList.remove('active');
            viewJoin.classList.remove('hidden');
            viewCreate.classList.add('hidden');
            viewLobby.classList.add('hidden');
        });

        tabLobby?.addEventListener('click', () => {
            tabLobby.classList.add('active');
            tabCreate.classList.remove('active');
            tabJoin.classList.remove('active');
            viewLobby.classList.remove('hidden');
            viewCreate.classList.add('hidden');
            viewJoin.classList.add('hidden');
        });

        // Random code generator button
        const btnRandomCode = document.getElementById('btn-random-code');
        btnRandomCode?.addEventListener('click', () => {
            const input = document.getElementById('create-room-code');
            if (input) input.value = HeartsNetwork.generateRoomCode();
        });

        // Password eye toggles
        document.getElementById('btn-toggle-create-pwd')?.addEventListener('click', () => {
            const input = document.getElementById('create-room-password');
            if (input) input.type = input.type === 'password' ? 'text' : 'password';
        });

        document.getElementById('btn-toggle-join-pwd')?.addEventListener('click', () => {
            const input = document.getElementById('join-room-password');
            if (input) input.type = input.type === 'password' ? 'text' : 'password';
        });

        // Create Room Action
        document.getElementById('btn-action-create')?.addEventListener('click', () => {
            const name = document.getElementById('create-player-name')?.value.trim() || 'Host';
            const code = document.getElementById('create-room-code')?.value.trim() || HeartsNetwork.generateRoomCode();
            const pwd = document.getElementById('create-room-password')?.value.trim();
            const mode = document.getElementById('create-game-mode')?.value || 'classic';

            if (!pwd) {
                this.showToast('Please specify a room password to protect your room.');
                return;
            }

            window.heartsNetwork.createRoom({
                roomCode: code,
                password: pwd,
                hostName: name,
                gameMode: mode
            });

            this.showOnlineModal({ tab: 'lobby' });
        });

        // Join Room Action
        document.getElementById('btn-action-join')?.addEventListener('click', () => {
            const name = document.getElementById('join-player-name')?.value.trim() || 'Guest';
            const code = document.getElementById('join-room-code')?.value.trim();
            const pwd = document.getElementById('join-room-password')?.value.trim();

            if (!code) {
                this.showToast('Please enter the room code.');
                return;
            }
            if (!pwd) {
                this.showToast('Please enter the room password.');
                return;
            }

            window.heartsNetwork.joinRoom({
                roomCode: code,
                password: pwd,
                playerName: name
            });

            this.showOnlineModal({ tab: 'lobby' });
        });

        // Copy Share URL
        const copyHandler = () => {
            const link = window.heartsNetwork.getShareableLink();
            if (!link) return;
            navigator.clipboard.writeText(link).then(() => {
                const feedback = document.getElementById('copy-feedback');
                if (feedback) {
                    feedback.classList.remove('hidden');
                    setTimeout(() => feedback.classList.add('hidden'), 3500);
                }
                this.showToast('✓ Direct invite link copied to clipboard!', 3000);
            }).catch(() => {
                const input = document.getElementById('lobby-share-url');
                if (input) {
                    input.select();
                    document.execCommand('copy');
                    this.showToast('✓ Link copied!', 3000);
                }
            });
        };

        document.getElementById('btn-copy-share-url')?.addEventListener('click', copyHandler);
        this.btnHudCopy?.addEventListener('click', copyHandler);

        // Start Online Game (Host only)
        document.getElementById('btn-lobby-start-game')?.addEventListener('click', () => {
            if (!window.heartsNetwork.isHost) return;

            const seats = window.heartsNetwork.lobbySeats;
            const humanSeats = seats.filter(s => s.isHuman && s.isConnected).map(s => s.seatIndex);
            const playerNames = seats.map(s => s.name);
            const playerAvatars = seats.map(s => s.avatar);
            const gameMode = window.heartsNetwork.gameMode;

            // Initialize game on Host
            const onlineGame = new HeartsGame({
                gameMode,
                humanSeats,
                playerNames
            });

            this.bindGame(onlineGame);
            this.modalOnline.classList.add('hidden');

            if (this.onlineHudEl) {
                this.onlineHudEl.classList.remove('hidden');
                if (this.hudRoomCodeEl) this.hudRoomCodeEl.textContent = `Room: ${window.heartsNetwork.roomCode}`;
            }

            // Broadcast game start to all connected guests
            window.heartsNetwork.broadcastToGuests({
                type: 'game_start',
                gameMode,
                humanSeats,
                playerNames,
                playerAvatars
            });

            onlineGame.startNewGame();
        });

        // Leave Lobby Action
        document.getElementById('btn-leave-lobby')?.addEventListener('click', () => {
            window.heartsNetwork.leaveRoom();
            this.showOnlineModal({ tab: 'create' });
            if (this.onlineHudEl) this.onlineHudEl.classList.add('hidden');
            this.showToast('You left the room.');
        });

        // Emote buttons
        document.querySelectorAll('.btn-emote').forEach(btn => {
            btn.addEventListener('click', () => {
                const emote = btn.getAttribute('data-emote');
                if (emote) {
                    window.heartsNetwork.sendEmote(emote);
                }
            });
        });

        // Chat send button & Enter key
        const sendChat = () => {
            if (!this.hudChatInput) return;
            const text = this.hudChatInput.value.trim();
            if (text) {
                window.heartsNetwork.sendChatMessage(text);
                this.hudChatInput.value = '';
            }
        };

        this.btnSendChat?.addEventListener('click', sendChat);
        this.hudChatInput?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') sendChat();
        });

        // Setup Network Listeners
        this.setupNetworkCallbacks();

        // Check for ?room=... in URL
        this.checkAutoJoinUrlParams();
    }

    setupNetworkCallbacks() {
        const net = window.heartsNetwork;
        if (!net) return;

        net.onLobbyUpdated = (lobbySeats, roomCode, password) => {
            this.renderLobbySeats(lobbySeats);
            const codeEl = document.getElementById('lobby-display-code');
            const pwdEl = document.getElementById('lobby-display-pwd');
            const urlInput = document.getElementById('lobby-share-url');
            const btnStart = document.getElementById('btn-lobby-start-game');
            const btnLeave = document.getElementById('btn-leave-lobby');

            if (codeEl) codeEl.textContent = roomCode;
            if (pwdEl) pwdEl.textContent = password || '(No password)';
            if (urlInput) urlInput.value = net.getShareableLink();

            if (btnLeave) btnLeave.classList.remove('hidden');

            if (net.isHost) {
                if (btnStart) btnStart.classList.remove('hidden');
            } else {
                if (btnStart) btnStart.classList.add('hidden');
            }
        };

        net.onConnectionStatus = (msg) => {
            const statusEl = document.getElementById('lobby-status-banner');
            if (statusEl) statusEl.textContent = msg;
            this.showToast(msg, 3000);
        };

        net.onError = (err) => {
            const statusEl = document.getElementById('lobby-status-banner');
            if (statusEl) statusEl.textContent = `Error: ${err}`;
            this.showToast(`⚠️ ${err}`, 5000);
        };

        net.onChatMessage = (senderSeat, senderName, text) => {
            this.showStationBubble(senderSeat, text, false);
        };

        net.onEmoteReceived = (senderSeat, emote) => {
            this.showStationBubble(senderSeat, emote, true);
        };

        // GUEST IN-GAME SYNCHRONIZATION
        net.onGameStarted = (data) => {
            this.onlineIsGuest = true;
            this.onlinePlayerNames = data.playerNames;
            this.onlinePlayerAvatars = data.playerAvatars;
            this.onlineGameMode = data.gameMode;
            this.onlineMySeat = net.mySeatIndex;

            // Perspective rotation: Guest sits at South (Bottom)!
            this.setViewingPlayer(this.onlineMySeat);

            if (this.modalOnline) this.modalOnline.classList.add('hidden');
            if (this.onlineHudEl) {
                this.onlineHudEl.classList.remove('hidden');
                if (this.hudRoomCodeEl) this.hudRoomCodeEl.textContent = `Room: ${net.roomCode} (Guest)`;
            }

            this.updateOnlinePlayerBadges();
            this.showToast(`Game Started by Host! Game Mode: ${data.gameMode === 'triple-pass' ? 'Triple Pass' : 'Classic'}.`, 3500);
        };

        net.onRoundDealt = (data) => {
            this.onlineGuestHand = data.myHand.map(c => new Card(c.suit, c.rank));
            this.onlinePassDirection = data.passDirection;
            this.onlinePassStage = data.passStage;
            this.onlineRoundNumber = data.roundNumber;
            this.onlineIsPassingPhase = data.passDirection !== 'hold';
            this.onlineCurrentTrick = [];
            this.selectedPassCardIds.clear();

            this.updateOnlinePlayerBadges(data.scores);
            this.renderOnlineGuestHand();
            this.renderOnlineStationCardCounts(13);

            if (this.centerTrickEl) this.centerTrickEl.innerHTML = '';

            if (this.onlineIsPassingPhase) {
                if (this.passControlsEl) {
                    this.passControlsEl.classList.remove('hidden');
                    if (this.passDirectionText) {
                        const dirLabel = data.gameMode === 'triple-pass'
                            ? HeartsRules.getTriplePassLabel(data.passStage)
                            : HeartsRules.getPassDirectionLabel(data.passDirection);
                        this.passDirectionText.textContent = dirLabel;
                    }
                    if (this.btnConfirmPass) {
                        this.btnConfirmPass.disabled = true;
                        this.btnConfirmPass.textContent = 'Pass 3 Cards (0/3)';
                    }
                }
                if (this.statusBannerEl) this.statusBannerEl.textContent = `Passing Phase: Select 3 cards to pass!`;
            } else {
                if (this.passControlsEl) this.passControlsEl.classList.add('hidden');
                if (this.statusBannerEl) this.statusBannerEl.textContent = `Hold Round (No Passing). Starting tricks!`;
            }

            if (window.soundEngine) window.soundEngine.playCardDeal();
        };

        net.onPassExchanged = (data) => {
            this.onlineGuestHand = data.myHand.map(c => new Card(c.suit, c.rank));
            this.onlineReceivedCards = (data.receivedCards || []).map(c => new Card(c.suit, c.rank));
            this.selectedPassCardIds.clear();
            this.onlineIsPassingPhase = data.nextPhase === HeartsGame.PHASES.PASSING;

            if (window.soundEngine) window.soundEngine.playCardPass();

            if (!this.onlineIsPassingPhase) {
                if (this.passControlsEl) this.passControlsEl.classList.add('hidden');
                this.showToast('Passing phase complete! Starting round.');
            } else {
                this.showToast(`Pass completed! Next stage starting.`);
            }

            this.renderOnlineGuestHand();
        };

        net.onTurnUpdated = (data) => {
            this.onlineActivePlayerIndex = data.activePlayerIndex;
            this.onlineCurrentTrick = (data.currentTrick || []).map(p => ({ playerIndex: p.playerIndex, card: new Card(p.card.suit, p.card.rank) }));
            this.onlineHeartsBroken = data.heartsBroken;
            this.onlineTrickNumber = data.trickNumber;

            this.updateOnlinePlayerBadges();
            this.renderOnlineGuestHand();

            const isMyTurn = data.activePlayerIndex === net.mySeatIndex;
            const activeName = this.onlinePlayerNames ? this.onlinePlayerNames[data.activePlayerIndex] : 'Player';
            if (this.statusBannerEl) {
                const heartsText = data.heartsBroken ? ' | Hearts Broken ♥' : '';
                this.statusBannerEl.textContent = isMyTurn
                    ? `Trick ${data.trickNumber}/13: It's YOUR TURN to play!${heartsText}`
                    : `Trick ${data.trickNumber}/13: Waiting for ${activeName} to play...${heartsText}`;
            }
        };

        net.onCardPlayed = (data) => {
            const playedCard = new Card(data.card.suit, data.card.rank);
            this.onlineCurrentTrick = this.onlineCurrentTrick || [];
            this.onlineCurrentTrick.push({ playerIndex: data.playerIndex, card: playedCard });
            this.onlineHeartsBroken = data.heartsBroken;
            this.onlineActivePlayerIndex = data.activePlayerIndex;

            if (window.soundEngine) {
                if (playedCard.isQueenOfSpades()) {
                    window.soundEngine.playQueenAlert();
                } else {
                    window.soundEngine.playCardPlay();
                }
            }

            this.renderOnlineCenterTrick(this.onlineCurrentTrick);
            this.updateOnlinePlayerBadges();

            // If card was played by someone other than me, decrement their hand display count
            if (data.playerIndex !== net.mySeatIndex) {
                const station = this.getStationForPlayerIndex(data.playerIndex);
                const container = this.playerContainers[station];
                if (container) {
                    const badge = container.querySelector('.card-count-badge');
                    if (badge) {
                        const currentCount = parseInt(badge.textContent) || 13;
                        const newCount = Math.max(0, currentCount - 1);
                        badge.textContent = `${newCount} cards`;
                    }
                }
            } else {
                // If played by me, remove from my local hand
                this.onlineGuestHand = (this.onlineGuestHand || []).filter(c => c.id !== playedCard.id);
                this.renderOnlineGuestHand();
            }
        };

        net.onTrickCompleted = (data) => {
            const winnerName = this.onlinePlayerNames ? this.onlinePlayerNames[data.winnerIndex] : 'Player';
            const ptText = data.points > 0 ? ` (+${data.points} pts)` : ' (0 pts)';
            this.showToast(`${winnerName} won the trick!${ptText}`, 2200);

            if (this.statusBannerEl) {
                this.statusBannerEl.textContent = `${winnerName} takes the trick!${ptText}`;
            }

            // Mark winner card
            if (this.centerTrickEl) {
                const completedTrick = data.trick || [];
                const winningCard = completedTrick.find(p => p.playerIndex === data.winnerIndex);
                if (winningCard) {
                    const cardEl = this.centerTrickEl.querySelector(`[data-card-id="${winningCard.card.id}"]`);
                    if (cardEl) {
                        cardEl.classList.add('trick-winning-card');
                        if (!cardEl.querySelector('.trick-winner-badge')) {
                            const badge = document.createElement('div');
                            badge.className = 'trick-winner-badge';
                            badge.textContent = '★ WINNER';
                            cardEl.appendChild(badge);
                        }
                    }
                }
            }
        };

        net.onTrickSwept = (data) => {
            this.sweepTrickCards(data.winnerIndex);
            this.onlineCurrentTrick = [];
            if (window.soundEngine) window.soundEngine.playTrickWin();
        };

        net.onRoundCompleted = (data) => {
            if (data.moonShooterName) {
                const moonModal = document.getElementById('modal-moon-shot');
                if (moonModal) {
                    document.getElementById('moon-shooter-name').textContent = `${data.moonShooterName} Shot the Moon! 🌕`;
                    moonModal.classList.remove('hidden');
                }
                if (window.soundEngine) window.soundEngine.playMoonFanfare();
            }
            this.updateOnlinePlayerBadges(data.totalScores);
            this.showToast('Round completed! Preparing next round...', 3000);
        };

        net.onGameOver = (data) => {
            const gameOverModal = document.getElementById('modal-game-over');
            if (gameOverModal) {
                const winnerName = this.onlinePlayerNames ? this.onlinePlayerNames[data.winnerIndex] : 'Winner';
                document.getElementById('game-over-title').textContent = `${winnerName} Wins! 🏆`;
                gameOverModal.classList.remove('hidden');
            }
        };
    }

    renderLobbySeats(lobbySeats) {
        const container = document.getElementById('lobby-seats-list');
        if (!container) return;
        container.innerHTML = '';

        lobbySeats.forEach((seat, idx) => {
            const card = document.createElement('div');
            card.className = `lobby-seat-card ${seat.isConnected ? 'connected' : 'waiting'}`;

            const statusClass = seat.isConnected ? 'ready' : (seat.isBot ? 'bot' : 'waiting');
            const statusText = seat.isConnected
                ? (idx === 0 ? 'Host (Ready)' : 'Connected')
                : (seat.isBot ? 'AI Bot' : 'Waiting...');

            card.innerHTML = `
                <div class="seat-avatar">${seat.avatar || '🧑‍💻'}</div>
                <div class="seat-details">
                    <div class="seat-name">Seat ${idx + 1}: ${seat.name}</div>
                    <span class="seat-status-pill ${statusClass}">${statusText}</span>
                </div>
            `;
            container.appendChild(card);
        });
    }

    renderOnlineGuestHand() {
        if (!this.playerContainers[0]) return;
        const handContainer = this.playerContainers[0].querySelector('.hand-cards');
        if (!handContainer) return;
        handContainer.innerHTML = '';

        if (!this.onlineGuestHand) return;

        // Sort guest hand
        const suitOrder = { clubs: 0, diamonds: 1, spades: 2, hearts: 3 };
        this.onlineGuestHand.sort((a, b) => {
            if (suitOrder[a.suit] !== suitOrder[b.suit]) return suitOrder[a.suit] - suitOrder[b.suit];
            return a.rank - b.rank;
        });

        const isPassingPhase = this.onlineIsPassingPhase;
        const mySeat = window.heartsNetwork ? window.heartsNetwork.mySeatIndex : 1;
        const isMyTurn = this.onlineActivePlayerIndex === mySeat;
        const isFirstTrick = (this.onlineTrickNumber || 1) === 1;

        this.onlineGuestHand.forEach((card) => {
            const cardEl = document.createElement('div');
            cardEl.className = 'card-wrapper card-interactive';
            cardEl.dataset.cardId = card.id;

            const isSelected = this.selectedPassCardIds.has(card.id);
            if (isSelected) {
                cardEl.classList.add('selected-pass');
                const badge = document.createElement('div');
                badge.className = 'pass-badge-indicator';
                badge.textContent = '▲ PASS';
                cardEl.appendChild(badge);
            }

            if (isPassingPhase && this.onlineReceivedCards && this.onlineReceivedCards.some(rc => rc.id === card.id)) {
                cardEl.classList.add('newly-received');
            }

            if (isMyTurn && !isPassingPhase) {
                const isLegal = HeartsRules.isCardPlayable(card, this.onlineGuestHand, this.onlineCurrentTrick || [], this.onlineHeartsBroken, isFirstTrick);
                if (isLegal) {
                    cardEl.classList.add('playable');
                } else {
                    cardEl.classList.add('unplayable');
                }
            }

            cardEl.innerHTML = CardRenderer.renderCardFace(card);

            cardEl.addEventListener('click', (e) => {
                e.stopPropagation();
                this.handleCardClick(mySeat, card);
            });

            handContainer.appendChild(cardEl);
        });
    }

    renderOnlineStationCardCounts(count) {
        const cardBackSvg = CardRenderer.renderCardBack('sapphire');
        for (let station = 1; station < 4; station++) {
            const container = this.playerContainers[station];
            if (!container) continue;
            const handCards = container.querySelector('.hand-cards');
            if (handCards) {
                handCards.innerHTML = '';
                for (let i = 0; i < Math.min(count, 13); i++) {
                    const cardEl = document.createElement('div');
                    cardEl.className = 'card-wrapper card-facedown';
                    cardEl.innerHTML = cardBackSvg;
                    handCards.appendChild(cardEl);
                }
            }
            const badge = container.querySelector('.card-count-badge');
            if (badge) {
                badge.textContent = `${count} cards`;
                badge.style.display = count > 0 ? 'inline-block' : 'none';
            }
        }
    }

    renderOnlineCenterTrick(trick) {
        if (!this.centerTrickEl) return;
        if (!trick || trick.length === 0) {
            this.centerTrickEl.innerHTML = '';
            return;
        }

        const positions = ['pos-south', 'pos-west', 'pos-north', 'pos-east'];

        trick.forEach(({ playerIndex, card }) => {
            let cardEl = this.centerTrickEl.querySelector(`[data-card-id="${card.id}"]`);
            if (!cardEl) {
                const station = this.getStationForPlayerIndex(playerIndex);
                cardEl = document.createElement('div');
                cardEl.className = `trick-card ${positions[station]}`;
                cardEl.dataset.cardId = card.id;
                cardEl.innerHTML = CardRenderer.renderCardFace(card);
                this.centerTrickEl.appendChild(cardEl);
            }
        });
    }

    updateOnlinePlayerBadges(scores = null) {
        if (!this.onlinePlayerNames) return;
        const mySeat = window.heartsNetwork ? window.heartsNetwork.mySeatIndex : 0;

        this.playerContainers.forEach((container, station) => {
            const playerIndex = this.getPlayerIndexForStation(station);
            const nameEl = container.querySelector('.player-name');
            const turnIndicator = container.querySelector('.turn-glow');
            const avatarEl = container.querySelector('.avatar-circle');
            const totalScoreEl = container.querySelector('.player-total-score');

            if (nameEl) {
                const isMe = playerIndex === mySeat;
                nameEl.textContent = isMe ? `${this.onlinePlayerNames[playerIndex]} (You)` : this.onlinePlayerNames[playerIndex];
            }
            if (avatarEl && this.onlinePlayerAvatars) {
                avatarEl.textContent = this.onlinePlayerAvatars[playerIndex] || '🧑‍💻';
            }
            if (totalScoreEl && scores && scores[playerIndex] !== undefined) {
                totalScoreEl.textContent = `Total: ${scores[playerIndex]}`;
            }

            const isTurn = this.onlineActivePlayerIndex === playerIndex;
            if (turnIndicator) {
                turnIndicator.classList.toggle('active-turn', isTurn);
            }
        });
    }

    showStationBubble(seatIndex, text, isEmote = false) {
        const station = this.getStationForPlayerIndex(seatIndex);
        const stationEl = this.playerContainers[station];
        if (!stationEl) return;

        let bubbleEl = stationEl.querySelector('.station-speech-bubble');
        if (!bubbleEl) {
            bubbleEl = document.createElement('div');
            bubbleEl.className = 'station-speech-bubble hidden';
            stationEl.appendChild(bubbleEl);
        }

        bubbleEl.textContent = text;
        bubbleEl.style.fontSize = isEmote ? '1.7rem' : '0.92rem';
        bubbleEl.classList.remove('hidden');

        if (window.soundEngine && isEmote) {
            window.soundEngine.playCardSnap();
        }

        clearTimeout(bubbleEl._hideTimeout);
        bubbleEl._hideTimeout = setTimeout(() => {
            bubbleEl.classList.add('hidden');
        }, 3500);
    }

    checkAutoJoinUrlParams() {
        try {
            const urlParams = new URLSearchParams(window.location.search);
            const roomParam = urlParams.get('room');
            const pwdParam = urlParams.get('pwd');
            if (roomParam) {
                setTimeout(() => {
                    this.showOnlineModal({
                        tab: 'join',
                        roomCode: roomParam,
                        password: pwdParam || ''
                    });
                    this.showToast('Online room invite detected! Ready to join.', 4000);
                }, 400);
            }
        } catch (e) {}
    }

    showOnlineModal(options = {}) {
        if (!this.modalOnline) return;

        const tabCreate = document.getElementById('tab-btn-create');
        const tabJoin = document.getElementById('tab-btn-join');
        const tabLobby = document.getElementById('tab-btn-lobby');
        const viewCreate = document.getElementById('view-create-room');
        const viewJoin = document.getElementById('view-join-room');
        const viewLobby = document.getElementById('view-lobby');

        const activeTab = options.tab || 'create';

        if (activeTab === 'join') {
            tabCreate?.classList.remove('active');
            tabJoin?.classList.add('active');
            tabLobby?.classList.add('hidden');
            viewCreate?.classList.add('hidden');
            viewJoin?.classList.remove('hidden');
            viewLobby?.classList.add('hidden');

            if (options.roomCode) {
                const joinCodeInput = document.getElementById('join-room-code');
                if (joinCodeInput) joinCodeInput.value = options.roomCode;
            }
            if (options.password !== undefined) {
                const joinPwdInput = document.getElementById('join-room-password');
                if (joinPwdInput) joinPwdInput.value = options.password;
            }
        } else if (activeTab === 'lobby') {
            tabCreate?.classList.remove('active');
            tabJoin?.classList.remove('active');
            tabLobby?.classList.remove('hidden');
            tabLobby?.classList.add('active');
            viewCreate?.classList.add('hidden');
            viewJoin?.classList.add('hidden');
            viewLobby?.classList.remove('hidden');
        } else {
            tabCreate?.classList.add('active');
            tabJoin?.classList.remove('active');
            tabLobby?.classList.add('hidden');
            viewCreate?.classList.remove('hidden');
            viewJoin?.classList.add('hidden');
            viewLobby?.classList.add('hidden');
        }

        this.modalOnline.classList.remove('hidden');
    }
}

window.TableUI = TableUI;
