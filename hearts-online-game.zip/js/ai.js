/**
 * Hearts AI Engine
 * Implements strategic decision making, card counting, void tracking,
 * moon-shooting ambition, moon defense & countering, and memory of passed cards.
 */

class HeartsAI {
    /**
     * Chooses 3 cards to pass during the passing phase
     * Supports both (player, hand, direction, difficulty) and legacy (hand, direction, difficulty)
     * @param {object|Array<Card>} playerOrHand
     * @param {Array<Card>|string} handOrDirection
     * @param {string} directionOrDifficulty
     * @param {string} maybeDifficulty
     * @returns {Array<Card>} 3 selected cards
     */
    static selectCardsToPass(playerOrHand, handOrDirection, directionOrDifficulty, maybeDifficulty) {
        let player = null;
        let hand = null;
        let direction = 'left';
        let difficulty = 'hard';

        if (Array.isArray(playerOrHand)) {
            hand = [...playerOrHand];
            direction = handOrDirection || 'left';
            difficulty = directionOrDifficulty || 'hard';
        } else {
            player = playerOrHand;
            hand = [...(handOrDirection || player.hand)];
            direction = directionOrDifficulty || 'left';
            difficulty = maybeDifficulty || 'hard';
        }

        const sortedHand = [...hand].sort((a, b) => b.rank - a.rank);

        // Easy difficulty: randomized / casual passing
        if (difficulty === 'easy') {
            const shuffled = [...hand].sort(() => Math.random() - 0.5);
            return shuffled.slice(0, 3);
        }

        // ========================================================
        // 1. MOON AMBITION CHECK
        // Should the bot attempt to Shoot the Moon?
        // ========================================================
        const hearts = hand.filter(c => c.suit === SUITS.HEARTS);
        const highHearts = hearts.filter(c => c.rank >= 11);
        const spades = hand.filter(c => c.suit === SUITS.SPADES);
        const hasAceSpades = spades.some(c => c.rank === 14);
        const hasKingSpades = spades.some(c => c.rank === 13);
        const hasQueenSpades = hand.some(c => c.isQueenOfSpades());
        const totalAces = hand.filter(c => c.rank === 14).length;
        const totalKings = hand.filter(c => c.rank === 13).length;
        const totalHighCards = hand.filter(c => c.rank >= 11).length;

        // Moon qualification conditions:
        // A) Massive heart suit (>= 6) with high honors + strong spades
        const moonConditionA = hearts.length >= 6 && highHearts.length >= 3 && (hasQueenSpades || (hasAceSpades && hasKingSpades));
        // B) High concentration of top bosses across suits (>= 6 honors, >= 3 Aces/Kings)
        const moonConditionB = totalHighCards >= 6 && (totalAces + totalKings >= 3) && (hasQueenSpades || hasAceSpades || spades.length >= 4);
        // C) Opportunistic aggressive ambition (random chance if dealt strong hand)
        const moonConditionC = (difficulty === 'hard' && Math.random() < 0.28 && totalHighCards >= 5 && (totalAces + totalKings >= 2));

        const isAttemptingMoon = (moonConditionA || moonConditionB || moonConditionC) && difficulty !== 'easy';

        if (player && player.memory) {
            player.memory.attemptingMoon = isAttemptingMoon;
        }

        // --------------------------------------------------------
        // When Shooting the Moon:
        // KEEP: All high cards (ranks >= 10), high Hearts, Queen of Spades, Aces, Kings.
        // PASS: 3 LOW off-suit cards from shortest suits (giving opponents low junk).
        // --------------------------------------------------------
        if (isAttemptingMoon) {
            const lowJunkCandidates = hand.filter(c => {
                if (c.isQueenOfSpades()) return false;
                if (c.isHeart() && c.rank >= 9) return false;
                if (c.rank >= 11) return false; // Keep Jacks, Queens, Kings, Aces
                return true;
            });

            // Score junk candidates: prioritize lowest ranks and shortest suits
            const junkScores = lowJunkCandidates.map(card => {
                const suitCount = hand.filter(c => c.suit === card.suit).length;
                let score = 100 - card.rank * 5; // Lower rank = higher pass priority
                if (suitCount <= 2 && !card.isHeart()) score += 20; // Void short offsuits
                score += (Math.random() - 0.5) * 10;
                return { card, score };
            });

            junkScores.sort((a, b) => b.score - a.score);

            if (junkScores.length >= 3) {
                const selected = junkScores.slice(0, 3).map(item => item.card);
                if (player && player.memory) {
                    player.memory.passedCards = [...selected];
                }
                return selected;
            }
        }

        // ========================================================
        // 2. DEFENSIVE / TACTICAL PASSING WITH VARIETY & RANDOMIZATION
        // ========================================================
        if (player && player.memory) {
            player.memory.attemptingMoon = false;
        }

        // Personality style for this specific pass
        const botStyle = Math.random();
        const preferVoiding = botStyle < 0.45;       // 45% chance bot focuses heavily on creating voids
        const keepProtectedQueen = botStyle < 0.50;  // 50% chance bot holds Queen of Spades if guarded

        const spadeCount = spades.length;

        const cardScores = hand.map(card => {
            let score = 0;

            // 1. Queen of Spades
            if (card.isQueenOfSpades()) {
                if (spadeCount <= 3) {
                    // Unprotected: Highly dangerous to keep!
                    score += 180 + Math.random() * 30;
                } else {
                    // Protected (4+ spades in hand):
                    if (keepProtectedQueen) {
                        // Hold Queen as an ambush weapon to drop on opponent's Ace/King
                        score += 35 + Math.random() * 25;
                    } else {
                        score += 115 + Math.random() * 30;
                    }
                }
            }

            // 2. Ace and King of Spades
            if (card.suit === SUITS.SPADES && (card.rank === 14 || card.rank === 13)) {
                if (spadeCount <= 3) {
                    // Dangerous: might be forced to win Queen of Spades
                    score += 135 + Math.random() * 30;
                } else {
                    // Guarded: safer to hold
                    score += 55 + Math.random() * 25;
                }
            }

            // 3. High Hearts
            if (card.suit === SUITS.HEARTS) {
                if (card.rank === 14) score += 92 + Math.random() * 25; // Ace of Hearts
                else if (card.rank === 13) score += 82 + Math.random() * 25; // King of Hearts
                else if (card.rank === 12) score += 68 + Math.random() * 20; // Queen of Hearts
                else if (card.rank >= 10) score += 42 + Math.random() * 15;
                else score -= (20 - card.rank * 2); // Keep low hearts to duck!
            }

            // 4. Void Creation (Short Suits in Clubs & Diamonds)
            if (card.suit === SUITS.CLUBS || card.suit === SUITS.DIAMONDS) {
                const suitCount = hand.filter(c => c.suit === card.suit).length;
                if (suitCount === 1) {
                    // Singleton: passing it creates an instant void!
                    score += preferVoiding ? 95 : 65;
                } else if (suitCount === 2) {
                    score += preferVoiding ? 60 : 40;
                } else if (suitCount === 3) {
                    score += preferVoiding ? 35 : 20;
                }

                // High cards in offsuits
                if (card.rank === 14) score += 40 + Math.random() * 20; // Ace
                if (card.rank === 13) score += 30 + Math.random() * 18; // King
                if (card.rank === 12) score += 20 + Math.random() * 12; // Queen
            }

            // 5. Randomized Noise / Personality Jitter
            // Prevents bots from deterministically passing identical cards every round
            score += (Math.random() - 0.5) * 36;

            return { card, score };
        });

        cardScores.sort((a, b) => b.score - a.score);
        const selected = cardScores.slice(0, 3).map(item => item.card);

        if (player && player.memory) {
            player.memory.passedCards = [...selected];
        }

        return selected;
    }

    /**
     * Moon Shooter Detection
     * Identifies if an opponent is actively attempting or threatening to Shoot the Moon
     * @param {object} gameState
     * @param {number} botIndex
     * @returns {object|null} Threat info { playerIndex, playerName, points, isThreat } or null
     */
    static detectMoonShooter(gameState, botIndex) {
        if (!gameState || !gameState.players) return null;

        const players = gameState.players;
        const playersWithPoints = players.filter(p => (p.roundPoints || 0) > 0);

        // If at least two different players have points, the moon is mathematically busted!
        if (playersWithPoints.length > 1) {
            return null;
        }

        // If exactly one player has taken points so far
        if (playersWithPoints.length === 1) {
            const leader = playersWithPoints[0];
            // If the leader is the bot itself, return null (bot handles own moon ambition)
            if (leader.index === botIndex) return null;

            // Opponent has taken all points:
            // Threat if opponent took Queen (>= 13 pts) or has accumulated >= 3 points
            if (leader.roundPoints >= 3 || leader.roundPoints >= 13) {
                return {
                    playerIndex: leader.index,
                    playerName: leader.name,
                    points: leader.roundPoints,
                    isThreat: true
                };
            }
        }

        // Also detect if an opponent has aggressively won 3+ tricks early with boss cards
        const trickNumber = gameState.trickNumber || 1;
        if (trickNumber <= 7) {
            for (let i = 0; i < 4; i++) {
                if (i === botIndex) continue;
                const p = players[i];
                if (p.tricksTaken && p.tricksTaken.length >= 3) {
                    if (playersWithPoints.length === 0 || (playersWithPoints.length === 1 && playersWithPoints[0].index === i)) {
                        return {
                            playerIndex: i,
                            playerName: p.name,
                            points: p.roundPoints || 0,
                            isThreat: true
                        };
                    }
                }
            }
        }

        return null;
    }

    /**
     * Memory Counter Helper
     * Analyzes what cards the bot passed and to whom, checking if recipient can be countered
     */
    static getMemoryCounterInfo(gameState, botIndex) {
        const botMemory = gameState.botMemory || {};
        const passedCards = botMemory.passedCards || [];
        const passedTo = botMemory.passedTo;

        if (passedTo === null || passedTo === undefined || passedCards.length === 0) {
            return {
                passedTo: null,
                unplayedPassedCards: [],
                passedToHoldsQueen: false,
                passedToHoldsSpadeHonor: false,
                passedToHoldsHighHeart: false
            };
        }

        // Check which passed cards are still unplayed
        const playedCards = gameState.playedCards || [];
        const unplayedPassedCards = passedCards.filter(c => !playedCards.some(pc => pc.id === c.id));

        const passedToHoldsQueen = unplayedPassedCards.some(c => c.isQueenOfSpades());
        const passedToHoldsSpadeHonor = unplayedPassedCards.some(c => c.suit === SUITS.SPADES && c.rank >= 13);
        const passedToHoldsHighHeart = unplayedPassedCards.some(c => c.suit === SUITS.HEARTS && c.rank >= 12);

        return {
            passedTo,
            unplayedPassedCards,
            passedToHoldsQueen,
            passedToHoldsSpadeHonor,
            passedToHoldsHighHeart
        };
    }

    /**
     * Chooses the optimal legal card to play in the current trick
     * @param {Array<Card>} hand
     * @param {Array<{playerIndex: number, card: Card}>} currentTrick
     * @param {boolean} heartsBroken
     * @param {boolean} isFirstTrick
     * @param {object} gameState
     * @param {string} difficulty
     * @returns {Card}
     */
    static selectCardToPlay(hand, currentTrick, heartsBroken, isFirstTrick, gameState = {}, difficulty = 'hard') {
        const legalCards = HeartsRules.getPlayableCards(hand, currentTrick, heartsBroken, isFirstTrick);
        if (legalCards.length === 1) {
            return legalCards[0];
        }

        // Easy bot: picks random legal card
        if (difficulty === 'easy') {
            const randomIndex = Math.floor(Math.random() * legalCards.length);
            return legalCards[randomIndex];
        }

        // 1. LEADING A TRICK (First player)
        if (currentTrick.length === 0) {
            return this.selectLeadCard(legalCards, hand, gameState, heartsBroken);
        }

        const ledSuit = currentTrick[0].card.suit;
        const followingSuit = legalCards.some(c => c.suit === ledSuit);

        // 2. FOLLOWING SUIT
        if (followingSuit) {
            return this.selectFollowCard(legalCards, currentTrick, hand, gameState);
        }

        // 3. VOID IN SUIT -> DISCARDING!
        return this.selectDiscardCard(legalCards, currentTrick, hand, gameState, isFirstTrick);
    }

    /**
     * Strategy when leading a trick (First player)
     */
    static selectLeadCard(legalCards, hand, gameState, heartsBroken) {
        const botIndex = gameState.activePlayerIndex;
        const botMemory = gameState.botMemory || {};
        const mem = this.getMemoryCounterInfo(gameState, botIndex);
        const moonShooter = this.detectMoonShooter(gameState, botIndex);

        // ========================================================
        // A. BOT IS ACTIVELY SHOOTING THE MOON
        // ========================================================
        if (botMemory.attemptingMoon) {
            // Verify moon is still mathematically alive
            const players = gameState.players || [];
            const otherPlayerWithPoints = players.some(p => p.index !== botIndex && (p.roundPoints || 0) > 0);
            if (otherPlayerWithPoints) {
                botMemory.attemptingMoon = false; // Moon is broken, revert to defense
            } else {
                // Moon is active: Lead boss cards (Aces, high Kings) to sweep tricks
                const bossCards = legalCards.filter(c => c.rank >= 13).sort((a, b) => b.rank - a.rank);
                if (bossCards.length > 0) {
                    return bossCards[0];
                }
                // Lead top hearts if broken
                if (heartsBroken) {
                    const topHearts = legalCards.filter(c => c.isHeart()).sort((a, b) => b.rank - a.rank);
                    if (topHearts.length > 0) return topHearts[0];
                }
                // Otherwise lead highest available card to retain control
                legalCards.sort((a, b) => b.rank - a.rank);
                return legalCards[0];
            }
        }

        // ========================================================
        // B. DEFENDING AGAINST ENEMY MOON SHOOTER
        // ========================================================
        if (moonShooter) {
            // Avoid leading high hearts or Queen of Spades
            // Lead low cards in suits where defenders can compete
            const safeNonPoints = legalCards.filter(c => !c.isHeart() && !c.isQueenOfSpades());
            if (safeNonPoints.length > 0) {
                safeNonPoints.sort((a, b) => a.rank - b.rank);
                return safeNonPoints[0]; // Lead lowest safe card
            }
        }

        // ========================================================
        // C. MEMORY COUNTER LEADS
        // ========================================================
        // 1. If we passed Queen of Spades to recipient, we know they hold Q♠!
        if (mem.passedToHoldsQueen) {
            // Do NOT lead high Spades (A♠, K♠) into them!
            // Lead low off-suits to force them to follow suit and preserve high cards
            const nonSpades = legalCards.filter(c => c.suit !== SUITS.SPADES);
            if (nonSpades.length > 0) {
                const lowNonSpades = nonSpades.filter(c => c.rank <= 8).sort((a, b) => a.rank - b.rank);
                if (lowNonSpades.length > 0) return lowNonSpades[0];
            }
        }

        // 2. If we passed Ace or King of Spades to recipient, avoid leading K♠ or Q♠ into them
        if (mem.passedToHoldsSpadeHonor) {
            const safeLeads = legalCards.filter(c => !(c.suit === SUITS.SPADES && c.rank >= 12));
            if (safeLeads.length > 0) {
                const lowSafe = safeLeads.filter(c => c.rank <= 8).sort((a, b) => a.rank - b.rank);
                if (lowSafe.length > 0) return lowSafe[0];
            }
        }

        // ========================================================
        // D. STANDARD SAFE LEADING WITH TACTICAL VARIETY
        // ========================================================
        const queenPlayed = gameState.playedCards ? gameState.playedCards.some(c => c.isQueenOfSpades()) : false;

        const clubs = legalCards.filter(c => c.suit === SUITS.CLUBS);
        const diamonds = legalCards.filter(c => c.suit === SUITS.DIAMONDS);
        const spades = legalCards.filter(c => c.suit === SUITS.SPADES);
        const hearts = legalCards.filter(c => c.suit === SUITS.HEARTS);

        // Preference 1: Low clubs or low diamonds (Rank <= 8)
        const lowOffsuits = [...clubs, ...diamonds].filter(c => c.rank <= 8).sort((a, b) => a.rank - b.rank);
        if (lowOffsuits.length > 0) {
            // Slight variety: pick from the 2 lowest
            const pickIndex = (lowOffsuits.length > 1 && Math.random() < 0.3) ? 1 : 0;
            return lowOffsuits[pickIndex];
        }

        // Preference 2: Low spades if Queen not played and we have low spades to flush out Queen
        if (!queenPlayed && spades.length > 0) {
            const lowSpades = spades.filter(c => c.rank < 12).sort((a, b) => a.rank - b.rank);
            if (lowSpades.length > 0) {
                return lowSpades[0];
            }
        }

        // Preference 3: Any remaining club or diamond
        const remainingOffsuits = [...clubs, ...diamonds].sort((a, b) => a.rank - b.rank);
        if (remainingOffsuits.length > 0) {
            return remainingOffsuits[0];
        }

        // Preference 4: Low hearts if hearts are broken
        if (heartsBroken && hearts.length > 0) {
            hearts.sort((a, b) => a.rank - b.rank);
            return hearts[0];
        }

        // Fallback: Lowest rank legal card
        legalCards.sort((a, b) => a.rank - b.rank);
        return legalCards[0];
    }

    /**
     * Strategy when following the led suit
     */
    static selectFollowCard(legalCards, currentTrick, hand, gameState) {
        const botIndex = gameState.activePlayerIndex;
        const botMemory = gameState.botMemory || {};
        const ledSuit = currentTrick[0].card.suit;
        const trickCardsOfSuit = currentTrick.filter(p => p.card.suit === ledSuit);

        // Find the current winning card and player of this trick
        const currentHighPlay = trickCardsOfSuit.reduce((max, p) => p.card.rank > max.card.rank ? p : max, trickCardsOfSuit[0]);
        const currentHighCard = currentHighPlay.card;
        const currentWinnerIndex = currentHighPlay.playerIndex;

        const trickPoints = HeartsRules.calculatePoints(currentTrick.map(p => p.card));
        const isSpades = ledSuit === SUITS.SPADES;
        const queenPlayed = gameState.playedCards ? gameState.playedCards.some(c => c.isQueenOfSpades()) : false;
        const hasQueenInTrick = currentTrick.some(p => p.card.isQueenOfSpades());
        const isLastPlayer = currentTrick.length === 3;

        // Cards strictly under current high card (ducking: safe from winning)
        const duckingCards = legalCards.filter(c => c.rank < currentHighCard.rank).sort((a, b) => b.rank - a.rank);

        // Cards higher than current high card (taking the trick: lowest taking first)
        const takingCards = legalCards.filter(c => c.rank > currentHighCard.rank).sort((a, b) => a.rank - b.rank);
        const lowestTakingCard = takingCards[0];
        const highestTakingCard = takingCards[takingCards.length - 1];

        const moonShooter = this.detectMoonShooter(gameState, botIndex);
        const mem = this.getMemoryCounterInfo(gameState, botIndex);

        // ========================================================
        // 1. EMERGENCY MOON DEFENSE: BREAK THE OPPONENT'S MOON SHOT!
        // ========================================================
        if (moonShooter) {
            // Case A: The suspected shooter is currently winning this trick!
            if (currentWinnerIndex === moonShooter.playerIndex) {
                // If this trick has points, OR if someone might dump points:
                // WE MUST TAKE THE TRICK TO INTERCEPT THE POINTS AND BREAK THE MOON!
                if (takingCards.length > 0) {
                    // Play the lowest card that beats the shooter!
                    return lowestTakingCard;
                }
            } else {
                // Case B: Another defender is currently winning the trick!
                // If the trick has points, the other defender will capture them and bust the moon!
                // Bot should duck to let the teammate break the moon!
                if (duckingCards.length > 0) {
                    return duckingCards[0];
                }
            }
        }

        // ========================================================
        // 2. BOT'S OWN MOON ATTEMPT
        // ========================================================
        if (botMemory.attemptingMoon) {
            const players = gameState.players || [];
            const otherPlayerWithPoints = players.some(p => p.index !== botIndex && (p.roundPoints || 0) > 0);
            if (otherPlayerWithPoints) {
                botMemory.attemptingMoon = false;
            } else {
                // Bot wants to win tricks to sweep all 26 points
                if (takingCards.length > 0) {
                    return highestTakingCard; // Win with highest card to dominate
                }
                if (duckingCards.length > 0) {
                    return duckingCards[0]; // Play highest ducking card
                }
            }
        }

        // ========================================================
        // 3. MEMORY COUNTER: UNDER-DROP QUEEN OF SPADES ON PASSED ACE/KING!
        // If we passed A♠/K♠ to recipient, and recipient is currently winning with A♠/K♠,
        // and we hold Q♠ (rank 12 is lower than 13 and 14), DROP QUEEN DIRECTLY ON THEM!
        // ========================================================
        if (isSpades && currentWinnerIndex === mem.passedTo && (currentHighCard.rank === 14 || currentHighCard.rank === 13)) {
            const queenOfSpades = legalCards.find(c => c.isQueenOfSpades());
            if (queenOfSpades) {
                // If recipient is actively threatening to shoot the moon and moon is unbroken,
                // do NOT voluntarily feed them 13 points towards the moon!
                const isMoonThreat = moonShooter && moonShooter.playerIndex === mem.passedTo;
                const players = gameState.players || [];
                const moonAlreadyBroken = players.filter(p => (p.roundPoints || 0) > 0).length > 1;

                if (!isMoonThreat || moonAlreadyBroken) {
                    return queenOfSpades;
                }
            }
        }

        // ========================================================
        // 4. QUEEN OF SPADES IN THE TRICK OR LED
        // ========================================================
        if (hasQueenInTrick) {
            if (duckingCards.length > 0) {
                return duckingCards[0]; // Duck with highest safe card below Queen/lead
            }
            // Forced to take the Queen: burn highest card to get rid of dangerous spade
            return highestTakingCard || legalCards[0];
        }

        // ========================================================
        // 5. TRICK CONTAINS POINTS (HEARTS)
        // ========================================================
        if (trickPoints > 0) {
            if (duckingCards.length > 0) {
                return duckingCards[0]; // Duck with highest card lower than winning card
            }
            // Forced to take points: burn highest taking card
            return highestTakingCard;
        }

        // ========================================================
        // 6. SAFE TRICK (NO POINTS IN TRICK SO FAR)
        // ========================================================
        if (isLastPlayer) {
            // As 4th player, no one else can drop points behind us!
            // If taking the trick gets rid of an honor safely, do it
            if (takingCards.length > 0 && takingCards[0].rank <= 11) {
                return takingCards[0];
            }
            if (duckingCards.length > 0) {
                return duckingCards[0];
            }
            return lowestTakingCard;
        }

        // 2nd or 3rd player: someone behind us could dump Queen or Hearts!
        if (isSpades && !queenPlayed) {
            // Avoid Ace/King of Spades if Queen hasn't dropped!
            const safeSpades = legalCards.filter(c => c.rank < 12);
            if (safeSpades.length > 0) {
                safeSpades.sort((a, b) => a.rank - b.rank);
                return safeSpades[0];
            }
        }

        // Default: Duck with highest safe card, or play lowest taking card
        if (duckingCards.length > 0) {
            return duckingCards[0];
        }
        return lowestTakingCard;
    }

    /**
     * Strategy when discarding (void in led suit)
     */
    static selectDiscardCard(legalCards, currentTrick, hand, gameState, isFirstTrick) {
        // Trick 1 constraint handled by legalCards (no points allowed on first trick)
        const botIndex = gameState.activePlayerIndex;
        const botMemory = gameState.botMemory || {};
        const ledSuit = currentTrick[0].card.suit;
        const currentHighPlay = currentTrick.filter(p => p.card.suit === ledSuit).reduce(
            (max, p) => p.card.rank > max.card.rank ? p : max,
            currentTrick[0]
        );
        const currentWinnerIndex = currentHighPlay.playerIndex;

        const moonShooter = this.detectMoonShooter(gameState, botIndex);
        const mem = this.getMemoryCounterInfo(gameState, botIndex);

        // ========================================================
        // 1. MOON DEFENSE DISCARD TACTICS
        // ========================================================
        if (moonShooter) {
            // If another defender is winning this trick:
            // DUMP A POINT (any heart) ON THE DEFENDER TO BREAK THE MOON!
            if (currentWinnerIndex !== moonShooter.playerIndex) {
                const hearts = legalCards.filter(c => c.isHeart()).sort((a, b) => a.rank - b.rank);
                if (hearts.length > 0) {
                    return hearts[0]; // 1 point is enough to shatter the moon!
                }
            } else {
                // The suspected shooter is winning this trick:
                // Check if the moon is already broken by someone having points
                const players = gameState.players || [];
                const pointsSplit = players.filter(p => (p.roundPoints || 0) > 0).length > 1;

                if (pointsSplit) {
                    // Moon is already dead! Slam maximum points on the shooter!
                    const queen = legalCards.find(c => c.isQueenOfSpades());
                    if (queen) return queen;
                    const highHearts = legalCards.filter(c => c.isHeart()).sort((a, b) => b.rank - a.rank);
                    if (highHearts.length > 0) return highHearts[0];
                } else {
                    // Moon is still alive: DO NOT feed points to the shooter!
                    // Discard dangerous non-point high cards (Aces, Kings of offsuits)
                    const safeDiscards = legalCards.filter(c => !c.isHeart() && !c.isQueenOfSpades())
                        .sort((a, b) => b.rank - a.rank);
                    if (safeDiscards.length > 0) {
                        return safeDiscards[0];
                    }
                }
            }
        }

        // ========================================================
        // 2. BOT'S OWN MOON ATTEMPT
        // ========================================================
        if (botMemory.attemptingMoon) {
            // Discard lowest non-point card to keep all power cards
            const lowJunk = legalCards.filter(c => !c.isHeart() && !c.isQueenOfSpades())
                .sort((a, b) => a.rank - b.rank);
            if (lowJunk.length > 0) return lowJunk[0];
        }

        // ========================================================
        // 3. MEMORY COUNTER: PUNISH RECIPIENT OF PASSED CARDS
        // If recipient is winning this trick, dump Queen or high Hearts on them!
        // ========================================================
        if (currentWinnerIndex === mem.passedTo) {
            const isMoonThreat = moonShooter && moonShooter.playerIndex === mem.passedTo;
            const players = gameState.players || [];
            const moonAlreadyBroken = players.filter(p => (p.roundPoints || 0) > 0).length > 1;

            if (!isMoonThreat || moonAlreadyBroken) {
                const queen = legalCards.find(c => c.isQueenOfSpades());
                if (queen) return queen;

                const highHearts = legalCards.filter(c => c.isHeart()).sort((a, b) => b.rank - a.rank);
                if (highHearts.length > 0) return highHearts[0];
            }
        }

        // ========================================================
        // 4. STANDARD DISCARD PRIORITY
        // ========================================================
        // 1. Dump Queen of Spades if held!
        const queen = legalCards.find(c => c.isQueenOfSpades());
        if (queen) {
            return queen;
        }

        // 2. Dump High Hearts (A, K, Q, J)
        const highHearts = legalCards.filter(c => c.isHeart()).sort((a, b) => b.rank - a.rank);
        if (highHearts.length > 0 && highHearts[0].rank >= 10) {
            return highHearts[0];
        }

        // 3. Dump Dangerous Spades (A♠, K♠)
        const dangerousSpades = legalCards.filter(c => c.suit === SUITS.SPADES && c.rank >= 13).sort((a, b) => b.rank - a.rank);
        if (dangerousSpades.length > 0) {
            return dangerousSpades[0];
        }

        // 4. Dump any other Hearts
        if (highHearts.length > 0) {
            return highHearts[0];
        }

        // 5. Dump highest off-suit cards (Aces and Kings of Clubs/Diamonds)
        const highOffsuits = legalCards.sort((a, b) => b.rank - a.rank);
        return highOffsuits[0];
    }

    /**
     * Generates a helpful MobilityWare-style hint for the human player
     * @returns {{card: Card, reason: string}}
     */
    static getHint(hand, currentTrick, heartsBroken, isFirstTrick, gameState = {}) {
        const bestCard = this.selectCardToPlay(hand, currentTrick, heartsBroken, isFirstTrick, gameState, 'hard');
        let reason = '';

        const moonShooter = this.detectMoonShooter(gameState, gameState.activePlayerIndex || 0);

        if (isFirstTrick && currentTrick.length === 0) {
            reason = 'Rule: You must lead the Two of Clubs on the first trick of the hand.';
        } else if (moonShooter && currentTrick.length > 0) {
            reason = `Moon Defense! Opponent ${moonShooter.playerName} is threatening to Shoot the Moon. Play ${bestCard.toString()} to contest the trick and bust their moon shot!`;
        } else if (bestCard.isQueenOfSpades() && currentTrick.length > 0) {
            reason = 'Discard the Queen of Spades immediately to dump 13 penalty points on the trick winner!';
        } else if (currentTrick.length === 0) {
            if (bestCard.rank <= 8) {
                reason = `Lead a low ${bestCard.suit} (${bestCard.name}) to safely retain control and avoid winning high cards.`;
            } else {
                reason = `Lead ${bestCard.toString()} as the safest available card.`;
            }
        } else {
            const ledSuit = currentTrick[0].card.suit;
            if (bestCard.suit === ledSuit) {
                const trickPoints = HeartsRules.calculatePoints(currentTrick.map(p => p.card));
                if (trickPoints > 0) {
                    reason = `Duck under the winning card with ${bestCard.toString()} to avoid taking penalty points.`;
                } else {
                    reason = `Follow suit with ${bestCard.toString()} to conserve your safer cards.`;
                }
            } else {
                if (bestCard.isHeart()) {
                    reason = `You are void in ${ledSuit}! Dump high heart ${bestCard.toString()} on this trick.`;
                } else {
                    reason = `You are void in ${ledSuit}! Safely discard your dangerous high ${bestCard.toString()}.`;
                }
            }
        }

        return { card: bestCard, reason };
    }
}

window.HeartsAI = HeartsAI;
