/**
 * Standard Rules Engine for Hearts: Card Game
 */

class HeartsRules {
    static GAME_MODES = {
        CLASSIC: 'classic',
        TRIPLE_PASS: 'triple-pass'
    };

    static PASS_DIRECTIONS = {
        LEFT: 'left',
        RIGHT: 'right',
        ACROSS: 'across',
        HOLD: 'hold'
    };

    /**
     * Determines passing direction for Triple Pass mode stages (1, 2, or 3)
     */
    static getTriplePassDirection(stage) {
        switch(stage) {
            case 1: return this.PASS_DIRECTIONS.LEFT;
            case 2: return this.PASS_DIRECTIONS.ACROSS;
            case 3: return this.PASS_DIRECTIONS.RIGHT;
            default: return this.PASS_DIRECTIONS.LEFT;
        }
    }

    static getTriplePassLabel(stage) {
        switch(stage) {
            case 1: return 'Triple Pass (Stage 1/3): Pass 3 cards to the Left';
            case 2: return 'Triple Pass (Stage 2/3): Pass 3 cards to the Person in Front (Across)';
            case 3: return 'Triple Pass (Stage 3/3): Pass 3 cards to the Right';
            default: return 'Passing Phase';
        }
    }

    /**
     * Determines the passing direction based on round number (1-based)
     */
    static getPassDirection(roundNumber) {
        const mod = (roundNumber - 1) % 4;
        switch(mod) {
            case 0: return this.PASS_DIRECTIONS.LEFT;
            case 1: return this.PASS_DIRECTIONS.RIGHT;
            case 2: return this.PASS_DIRECTIONS.ACROSS;
            case 3: return this.PASS_DIRECTIONS.HOLD;
        }
    }

    /**
     * Human-friendly label for pass direction
     */
    static getPassDirectionLabel(direction) {
        switch(direction) {
            case this.PASS_DIRECTIONS.LEFT: return 'Pass 3 cards to the Left';
            case this.PASS_DIRECTIONS.RIGHT: return 'Pass 3 cards to the Right';
            case this.PASS_DIRECTIONS.ACROSS: return 'Pass 3 cards Across';
            case this.PASS_DIRECTIONS.HOLD: return 'Hold Hand (No Passing)';
            default: return 'No Passing';
        }
    }

    /**
     * Calculates target player index for passed cards
     * playerIndex: 0 (South), 1 (West), 2 (North), 3 (East)
     */
    static getPassTargetIndex(playerIndex, direction, totalPlayers = 4) {
        switch(direction) {
            case this.PASS_DIRECTIONS.LEFT:
                return (playerIndex + 1) % totalPlayers; // Clockwise
            case this.PASS_DIRECTIONS.RIGHT:
                return (playerIndex + totalPlayers - 1) % totalPlayers; // Counter-clockwise
            case this.PASS_DIRECTIONS.ACROSS:
                return (playerIndex + 2) % totalPlayers; // Opposite
            case this.PASS_DIRECTIONS.HOLD:
            default:
                return playerIndex;
        }
    }

    /**
     * Determines whether a card can be legally played
     * @param {Card} card - The candidate card to play
     * @param {Array<Card>} hand - The player's current hand
     * @param {Array<{playerIndex: number, card: Card}>} currentTrick - Cards played in the active trick
     * @param {boolean} heartsBroken - Whether hearts have been broken this hand
     * @param {boolean} isFirstTrick - Whether this is the first trick of the hand
     */
    static isCardPlayable(card, hand, currentTrick, heartsBroken, isFirstTrick) {
        // Condition 1: First card of the entire round MUST be 2 of Clubs
        if (isFirstTrick && currentTrick.length === 0) {
            return card.isTwoOfClubs();
        }

        // Leading a trick (First player of this trick)
        if (currentTrick.length === 0) {
            // Cannot lead hearts unless hearts have been broken OR player only has hearts
            if (card.isHeart() && !heartsBroken) {
                const onlyHasHearts = hand.every(c => c.isHeart());
                return onlyHasHearts;
            }
            return true;
        }

        // Following suit
        const ledCard = currentTrick[0].card;
        const ledSuit = ledCard.suit;
        const hasLedSuit = hand.some(c => c.suit === ledSuit);

        if (hasLedSuit) {
            // Must follow suit!
            return card.suit === ledSuit;
        }

        // Player is void in the led suit: Discarding allowed!
        // Constraint on First Trick: No points (Hearts or Queen of Spades) can be dumped on trick 1 unless player has ONLY points
        if (isFirstTrick) {
            const isPointCard = card.isHeart() || card.isQueenOfSpades();
            if (isPointCard) {
                const onlyHasPoints = hand.every(c => c.isHeart() || c.isQueenOfSpades());
                return onlyHasPoints;
            }
        }

        return true;
    }

    /**
     * Returns an array of cards from the hand that are legal to play
     */
    static getPlayableCards(hand, currentTrick, heartsBroken, isFirstTrick) {
        return hand.filter(card => this.isCardPlayable(card, hand, currentTrick, heartsBroken, isFirstTrick));
    }

    /**
     * Evaluates the winner of a completed 4-card trick
     * Winner is the player who played the highest card of the suit led.
     * @param {Array<{playerIndex: number, card: Card}>} trick
     * @returns {number} Winning playerIndex
     */
    static evaluateTrickWinner(trick) {
        if (!trick || trick.length === 0) return 0;
        const ledSuit = trick[0].card.suit;
        let highestRank = -1;
        let winnerIndex = trick[0].playerIndex;

        for (const play of trick) {
            if (play.card.suit === ledSuit && play.card.rank > highestRank) {
                highestRank = play.card.rank;
                winnerIndex = play.playerIndex;
            }
        }
        return winnerIndex;
    }

    /**
     * Calculates total penalty points in a trick or hand
     */
    static calculatePoints(cards) {
        let points = 0;
        for (const card of cards) {
            points += card.points;
        }
        return points;
    }

    /**
     * Checks if a player shot the moon (took all 13 hearts + Queen of Spades = 26 points)
     * @param {number} pointsTaken
     */
    static isShootTheMoon(pointsTaken) {
        return pointsTaken === 26;
    }

    /**
     * Applies round scores accounting for Shoot the Moon
     * @param {Array<number>} roundPointsTaken - Array of points taken this round per player [p0, p1, p2, p3]
     * @param {string} moonRule - 'punishOpponents' (opponents +26, shooter 0) or 'bonusShooter' (shooter -26, opponents 0)
     * @returns {{finalScores: Array<number>, moonShooterIndex: number | null}}
     */
    static calculateRoundScoreDeltas(roundPointsTaken, moonRule = 'punishOpponents') {
        const moonShooterIndex = roundPointsTaken.findIndex(pts => this.isShootTheMoon(pts));

        if (moonShooterIndex !== -1) {
            const finalScores = [0, 0, 0, 0];
            if (moonRule === 'bonusShooter') {
                finalScores[moonShooterIndex] = -26;
            } else {
                // Standard: All other 3 players receive 26 penalty points
                for (let i = 0; i < 4; i++) {
                    if (i !== moonShooterIndex) {
                        finalScores[i] = 26;
                    }
                }
            }
            return { finalScores, moonShooterIndex };
        }

        return {
            finalScores: [...roundPointsTaken],
            moonShooterIndex: null
        };
    }
}

window.HeartsRules = HeartsRules;
